import ResizableTable from '../../components/ResizableTable'
import React, { useState, useEffect, useCallback } from 'react'
import { Table, Tag, Button, Modal, Form, Input, Select, Space, Popconfirm, Row, Col, Switch } from 'antd'
import {
  TeamOutlined, CheckCircleOutlined, StopOutlined, ApartmentOutlined,
  PlusOutlined, ReloadOutlined,
} from '@ant-design/icons'
import ThreeSectionPage, { ActionButtons } from '../../components/ThreeSectionPage'
import type { FilterItem, StatItem } from '../../components/ThreeSectionPage'
import api from '../../utils/api'
import UserScopeConfigModal from '../iam/components/UserScopeConfigModal'
import { useMessage, useApp } from '../../contexts/AppContext'

interface User {
  user_id: number
  username: string
  real_name: string
  employee_no: string
  department: string
  position: string
  role_id: number
  role?: { role_name: string }
  phone: string
  email: string
  status: string
  last_login_time: string
  pwd_reset_required: number
  remarks: string
}

interface Role {
  role_id: number
  role_name: string
}

interface QueryParams {
  page: number
  pageSize: number
  keyword: string
  status: string | undefined
  role_id: number | undefined
}

export default function UserManagement() {
  const message = useMessage()
  const { hasPermission } = useApp()
  const [data, setData] = useState<User[]>([])
  const [loading, setLoading] = useState(false)
  const [total, setTotal] = useState(0)
  const [roles, setRoles] = useState<Role[]>([])
  const [modalOpen, setModalOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [form] = Form.useForm()

  const [keywordInput, setKeywordInput] = useState('')
  const [statusInput, setStatusInput] = useState<string | undefined>(undefined)
  const [roleInput, setRoleInput] = useState<number | undefined>(undefined)

  // IAM V2: 用户独立数据权限配置 Modal
  const [scopeModalOpen, setScopeModalOpen] = useState(false)
  const [scopeUserId, setScopeUserId] = useState<number | null>(null)
  const [scopeUserName, setScopeUserName] = useState('')
  const [scopeRoleId, setScopeRoleId] = useState<number | null>(null)
  const [scopeRoleName, setScopeRoleName] = useState('')

  const [query, setQuery] = useState<QueryParams>({ page: 1, pageSize: 30, keyword: '', status: undefined, role_id: undefined })

  const stats: StatItem[] = [
    { label: '总用户数', value: total, icon: <TeamOutlined />, color: 'var(--color-primary)' },
    { label: '启用用户', value: data.filter(u => u.status === '启用').length, icon: <CheckCircleOutlined />, color: 'var(--color-success)' },
    { label: '禁用用户', value: data.filter(u => u.status === '禁用').length, icon: <StopOutlined />, color: 'var(--color-error)' },
    { label: '部门数', value: [...new Set(data.map(u => u.department).filter(Boolean))].length, icon: <ApartmentOutlined />, color: 'var(--color-warning)' },
  ]

  const roleOptions = roles.map(r => ({ label: r.role_name, value: r.role_id }))

  useEffect(() => {
    let cancelled = false
    const run = async () => {
      setLoading(true)
      try {
        const params: Record<string, unknown> = { page: query.page, pageSize: query.pageSize }
        if (query.keyword) params.keyword = query.keyword
        if (query.status !== undefined && query.status !== null) params.status = query.status
        if (query.role_id !== undefined && query.role_id !== null) params.role_id = query.role_id
        const res = await api.get('/system/users', { params })
        if (cancelled) return
        const list = res.data || []
        setData(list)
        setTotal(res.total || list.length)
      } catch (err: unknown) {
        if (!cancelled) {
          message.error(err instanceof Error ? err.message : '获取用户列表失败')
          setData([])
          setTotal(0)
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    run()
    return () => { cancelled = true }
  }, [query])

  useEffect(() => {
    let cancelled = false
    const run = async () => {
      try {
        const res = await api.get('/system/roles', { params: { pageSize: 200 } })
        if (!cancelled) setRoles(res.data || [])
      } catch (err) {
        if (!cancelled) setRoles([])
      }
    }
    run()
    return () => { cancelled = true }
  }, [])

  const refresh = useCallback(() => setQuery(q => ({ ...q })), [])

  const handleSearch = () => {
    setQuery(q => ({ ...q, page: 1, keyword: keywordInput, status: statusInput, role_id: roleInput }))
  }

  const handleReset = () => {
    setKeywordInput('')
    setStatusInput(undefined)
    setRoleInput(undefined)
    setQuery(q => ({ ...q, page: 1, keyword: '', status: undefined, role_id: undefined }))
  }

  const handleAdd = () => {
    setEditingUser(null)
    setModalOpen(true)
  }

  const handleEdit = (record: User) => {
    if (record.username === 'sysadmin') {
      message.warning('系统默认账户禁止编辑')
      return
    }
    setEditingUser(record)
    setModalOpen(true)
  }

  const handleAfterOpenChange = (open: boolean) => {
    if (!open) return
    if (editingUser) {
      form.setFieldsValue({
        username: editingUser.username,
        real_name: editingUser.real_name,
        employee_no: editingUser.employee_no,
        department: editingUser.department,
        role_id: editingUser.role_id,
        phone: editingUser.phone,
        email: editingUser.email,
        status: editingUser.status,
        position: editingUser.position,
        pwd_reset_required: !!editingUser.pwd_reset_required,
        remarks: editingUser.remarks,
      })
    } else {
      form.resetFields()
      form.setFieldsValue({ status: '启用', pwd_reset_required: false })
    }
  }

  const handleToggle = async (record: User) => {
    if (record.username === 'sysadmin') {
      message.warning('系统默认账户禁止启停')
      return
    }
    try {
      const res = await api.post(`/system/users/${record.user_id}/toggle`)
      message.success(res.message || (record.status === '启用' ? '已禁用该用户' : '已启用该用户'))
      refresh()
    } catch (err: unknown) {
      message.error(err instanceof Error ? err.message : '操作失败')
    }
  }

  const handleDelete = async (record: User) => {
    if (record.username === 'sysadmin') {
      message.warning('系统默认账户禁止删除')
      return
    }
    try {
      const res = await api.delete(`/system/users/${record.user_id}`)
      message.success(res.message || '删除成功')
      refresh()
    } catch (err: unknown) {
      message.error(err instanceof Error ? err.message : '删除失败')
    }
  }

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields()
      setSubmitting(true)
      const payload = { ...values }
      if (editingUser && !payload.password) delete payload.password
      payload.pwd_reset_required = payload.pwd_reset_required ? 1 : 0
      if (editingUser) {
        const res = await api.put(`/system/users/${editingUser.user_id}`, payload)
        message.success(res.message || '用户编辑成功')
      } else {
        const res = await api.post('/system/users', payload)
        message.success(res.message || '用户新增成功')
      }
      setModalOpen(false)
      refresh()
    } catch (e: unknown) {
      if ((e as { errorFields?: unknown[] })?.errorFields) return
      message.error(e instanceof Error ? e.message : '操作失败')
    } finally {
      setSubmitting(false)
    }
  }

  const filters: FilterItem[] = [
    { type: 'input', placeholder: '搜索用户名/姓名/工号', col: { span: 6 }, value: keywordInput, onChange: (e: React.ChangeEvent<HTMLInputElement>) => setKeywordInput(e.target.value) },
    { type: 'select', placeholder: '角色筛选', options: roleOptions, col: { span: 6 }, value: roleInput, onChange: (v: number | undefined) => setRoleInput(v) },
    {
      type: 'select', placeholder: '状态筛选', col: { span: 6 },
      options: [{ label: '启用', value: '启用' }, { label: '禁用', value: '禁用' }],
      value: statusInput, onChange: (v: string | undefined) => setStatusInput(v),
    },
  ]

  const columns = [
    { title: '用户名', dataIndex: 'username', key: 'username' },
    { title: '真实姓名', dataIndex: 'real_name', key: 'real_name' },
    { title: '工号', dataIndex: 'employee_no', key: 'employee_no' },
    { title: '部门', dataIndex: 'department', key: 'department' },
    { title: '岗位', dataIndex: 'position', key: 'position' },
    {
      title: '角色', key: 'role',
      render: (_: unknown, record: User) => record.role?.role_name || '-',
    },
    { title: '手机号', dataIndex: 'phone', key: 'phone' },
    {
      title: '状态', dataIndex: 'status', key: 'status',
      render: (v: string) => v === '启用' ? <Tag color="green">启用</Tag> : <Tag color="red">禁用</Tag>,
    },
    {
      title: '最后登录时间', dataIndex: 'last_login_time', key: 'last_login_time', width: 170,
      render: (v: string) => v ? String(v).replace('T', ' ').slice(0, 19) : '-',
    },
    {
      title: '操作', key: 'action',
      render: (_: unknown, record: User) => {
        const isProtected = record.username === 'sysadmin'
        return (
          <Space size="small">
            {hasPermission('system:user:update') && (
              <Button type="link" size="small" disabled={isProtected} onClick={() => handleEdit(record)}>编辑</Button>
            )}
            <Popconfirm
              title={isProtected ? '系统默认账户禁止操作' : (record.status === '启用' ? '确认禁用该用户？' : '确认启用该用户？')}
              onConfirm={() => handleToggle(record)}
              okText="确认"
              cancelText="取消"
              disabled={isProtected}
            >
              <Button
                type="link"
                size="small"
                danger={record.status === '启用'}
                disabled={isProtected}
              >
                {record.status === '启用' ? '禁用' : '启用'}
              </Button>
            </Popconfirm>
            {hasPermission('system:user:delete') && (
              <Popconfirm
                title={isProtected ? '系统默认账户禁止删除' : '确认删除该用户？'}
                description={isProtected ? undefined : '删除后不可恢复'}
                onConfirm={() => handleDelete(record)}
                okText="确认"
                cancelText="取消"
                disabled={isProtected}
              >
                <Button type="link" size="small" danger disabled={isProtected}>删除</Button>
              </Popconfirm>
            )}
            {/* IAM V2: 用户独立数据权限配置入口 */}
            {hasPermission('iam:user:data_scope') && (
              <Button type="link" size="small"
                onClick={() => {
                  setScopeUserId(record.user_id)
                  setScopeUserName(record.username)
                  setScopeRoleId(record.role_id ?? null)
                  setScopeRoleName(roles.find(r => r.role_id === record.role_id)?.role_name ?? '')
                  setScopeModalOpen(true)
                }}
              >数据权限</Button>
            )}
          </Space>
        )
      },
    },
  ]

  return (
    <>
      <ThreeSectionPage
        title="用户管理"
        breadcrumbs="系统管理 / 用户管理"
        stats={stats}
        filters={filters}
        onSearch={handleSearch}
        onReset={handleReset}
        actions={
          <ActionButtons
            hasAdd={false}
            hasExport={false}
            extra={[
              <Button key="add" type="primary" icon={<PlusOutlined />} onClick={handleAdd}>新增用户</Button>,
            ]}
          />
        }
        table={
          <ResizableTable tableKey="pages_system_UserManagement"             columns={columns}
            dataSource={data}
            rowKey="user_id"
            size="small"
            loading={loading}
            pagination={{
              current: query.page,
              pageSize: query.pageSize,
              total,
              showSizeChanger: true,
              showTotal: t => `共 ${t} 条`,
              onChange: (p, ps) => setQuery(q => ({ ...q, page: p, pageSize: ps })),
            }}
          />
        }
      />
      <Modal
        title={editingUser ? '编辑用户' : '新增用户'}
        open={modalOpen}
        onOk={handleSubmit}
        confirmLoading={submitting}
        onCancel={() => setModalOpen(false)}
        afterOpenChange={handleAfterOpenChange}
        okText="保存"
        cancelText="取消"
        width={640}
        destroyOnHidden
      >
        <Form form={form} layout="vertical" className="compact-form" preserve={false}>
          <Row gutter={12}>
            <Col span={12}>
              <Form.Item name="username" label="用户名" rules={[{ required: true, message: '请输入用户名' }]}>
                <Input placeholder="请输入用户名" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="real_name" label="真实姓名" rules={[{ required: true, message: '请输入真实姓名' }]}>
                <Input placeholder="请输入真实姓名" />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={12}>
            <Col span={12}>
              <Form.Item
                name="password"
                label="密码"
                rules={editingUser ? [] : [{ required: true, message: '请输入密码' }]}
                extra={editingUser ? '留空则不修改密码' : undefined}
              >
                <Input.Password placeholder={editingUser ? '留空则不修改' : '请输入密码'} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="employee_no" label="工号" rules={[{ required: true, message: '请输入工号' }]}>
                <Input placeholder="请输入工号" />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={12}>
            <Col span={12}>
              <Form.Item name="department" label="部门" rules={[{ required: true, message: '请输入部门' }]}>
                <Input placeholder="请输入部门" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="role_id" label="角色" rules={[{ required: true, message: '请选择角色' }]}>
                <Select placeholder="请选择角色" options={roleOptions} />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={12}>
            <Col span={12}>
              <Form.Item
                name="phone"
                label="手机号"
                rules={[{ pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号' }]}
              >
                <Input placeholder="请输入手机号" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="email"
                label="邮箱"
                rules={[{ type: 'email', message: '请输入正确的邮箱地址' }]}
              >
                <Input placeholder="请输入邮箱" />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={12}>
            <Col span={12}>
              <Form.Item name="status" label="状态" rules={[{ required: true, message: '请选择状态' }]}>
                <Select
                  placeholder="请选择状态"
                  options={[{ label: '启用', value: '启用' }, { label: '禁用', value: '禁用' }]}
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="position" label="岗位名称">
                <Input placeholder="请输入岗位名称" />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={12}>
            <Col span={12}>
              <Form.Item name="pwd_reset_required" label="首次登录需改密" valuePropName="checked">
                <Switch checkedChildren="是" unCheckedChildren="否" />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={12}>
            <Col span={24}>
              <Form.Item name="remarks" label="备注">
                <Input.TextArea placeholder="请输入备注信息" rows={2} />
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </Modal>

      {/* IAM V2: 用户独立数据权限配置 Modal */}
      <UserScopeConfigModal
        open={scopeModalOpen}
        onClose={() => setScopeModalOpen(false)}
        userId={scopeUserId}
        userName={scopeUserName}
        roleId={scopeRoleId}
        roleName={scopeRoleName}
      />
    </>
  )
}
