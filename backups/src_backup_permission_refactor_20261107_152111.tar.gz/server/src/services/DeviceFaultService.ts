/**
 * 设备故障管理 Service（DeviceFaultController 下沉）
 *
 * 状态流转：新建 → 已分配维修 → 维修中 → 待审批 → 已解决/已关闭
 */
import { Op } from 'sequelize'
import sequelize from '../config/database.js'
import { WILDCARD_PERM } from '../middleware/auth.js'
import {
  DeviceFault,
  DeviceFaultRepair,
  DeviceImage,
  Device,
  User,
  Role,
} from '../models/index.js'
import { generateDeviceFaultNo } from '../utils/sequence.js'
import { MAX_PAGE_SIZE } from '../utils/response.js'
import { AppError } from '../utils/error.js'
import { STATUS_MAP, STATUS_REVERSE, LEVEL_REVERSE } from '../models/DeviceFault.js'
import { nowBeijingDate } from '../utils/date.js'
import { logger } from '../utils/logger.js'

// ---------- 纯函数 ----------

/** 多等级参数解析：兼容数字/"严重"/"中等"/"轻微" */
export function parseFaultLevelParam(level: any): number[] | null {
  if (level === undefined || level === '' || level === null) return null
  const arr = Array.isArray(level) ? level : [level]
  const nums: number[] = []
  for (const l of arr) {
    const parts = typeof l === 'string' && l.includes(',') ? l.split(',') : [l]
    for (const p of parts) {
      const n = LEVEL_REVERSE[p as string] !== undefined
        ? LEVEL_REVERSE[p as string]
        : Number(p)
      if (!Number.isNaN(n)) nums.push(n)
    }
  }
  return nums.length ? nums : null
}

/** 多状态参数解析 */
export function parseFaultStatusParam(status: any): number[] | null {
  if (status === undefined || status === '' || status === null) return null
  const arr = Array.isArray(status) ? status : [status]
  const nums: number[] = []
  for (const s of arr) {
    const parts = typeof s === 'string' && s.includes(',') ? s.split(',') : [s]
    for (const p of parts) {
      const n = STATUS_REVERSE[p as string] !== undefined
        ? STATUS_REVERSE[p as string]
        : Number(p)
      if (!Number.isNaN(n)) nums.push(n)
    }
  }
  return nums.length ? nums : null
}

/** 构建故障列表 where */
export function buildFaultWhere(query: any): any {
  const where: any = {}
  const { fault_no, device_id, device_name, device_code, fault_level, status, start_date, end_date } = query

  if (fault_no) where.fault_no = { [Op.like]: `%${fault_no}%` }
  if (device_id) where.device_id = device_id
  if (device_name) where.device_name = { [Op.like]: `%${device_name}%` }
  if (device_code) where.device_code = { [Op.like]: `%${device_code}%` }
  const levelArr = parseFaultLevelParam(fault_level)
  if (levelArr) where.fault_level = { [Op.in]: levelArr }
  const statusArr = parseFaultStatusParam(status)
  if (statusArr) where.status = { [Op.in]: statusArr }
  if (start_date || end_date) {
    where.fault_time = {}
    if (start_date) where.fault_time[Op.gte] = new Date(String(start_date))
    if (end_date) where.fault_time[Op.lte] = new Date(new Date(String(end_date)).getTime() + 86400000)
  }
  return where
}

/** 计算维修成本（纯函数：spare_parts_cost + labor_cost + external_cost） */
export function calcRepairCost(repair: any): any {
  const parts: any[] = Array.isArray(repair.spare_parts_used) ? repair.spare_parts_used : []
  const sparePartsCost = parts.reduce((sum: number, p: any) => {
    return sum + (Number(p?.quantity) || 0) * (Number(p?.unit_price) || 0)
  }, 0)
  const laborHours = Number(repair.labor_hours) || 0
  const laborRate = Number(repair.labor_rate) || 0
  const laborCost = Number((laborHours * laborRate).toFixed(2))
  const externalCost = Number(repair.external_cost) || 0
  const totalCost = Number((sparePartsCost + laborCost + externalCost).toFixed(2))
  return {
    spare_parts_cost: Number(sparePartsCost.toFixed(2)),
    labor_cost: laborCost,
    external_cost: externalCost,
    total_cost: totalCost,
  }
}

// ---------- DB helper ----------

async function getFaultDetail(id: number) {
  const record = await DeviceFault.findOne({
    where: { fault_id: id },
    include: [
      { model: DeviceFaultRepair, as: 'repair_record', required: false, include: [
        { model: DeviceImage, as: 'repair_images', required: false, separate: true, order: [['sort_order', 'ASC'], ['image_id', 'ASC']] },
      ]},
      { model: DeviceImage, as: 'fault_images', required: false, separate: true, order: [['sort_order', 'ASC'], ['image_id', 'ASC']] },
    ],
  })
  return record ? record.toJSON() : null
}

// ---------- Service ----------

export const DeviceFaultService = {
  /** 分页查询故障列表（按角色过滤上报人） */
  async list(query: any, actor?: any) {
    const where = buildFaultWhere(query)
    const limit = Math.min(Number(query.pageSize) || 20, MAX_PAGE_SIZE)
    const offset = ((Number(query.page) || 1) - 1) * limit

    // 按权限过滤：有 device:fault:view_all 权限的角色看全部；否则只看自己上报的
    const permCodes: Set<string> = actor?.permCodes ?? new Set()
    const hasViewAll = permCodes.has(WILDCARD_PERM) || permCodes.has('device:fault:view_all')
    if (actor?.userId && !hasViewAll) {
      where.reporter_id = actor.userId
    }

    return await DeviceFault.findAndCountAll({
      where,
      limit,
      offset,
      order: [['fault_time', 'DESC'], ['fault_id', 'DESC']],
    })
  },

  /** 全量统计（按权限过滤，返回聚合 count） */
  async stats(actor?: any) {
    const where: any = {}
    const permCodes: Set<string> = actor?.permCodes ?? new Set()
    const hasViewAll = permCodes.has(WILDCARD_PERM) || permCodes.has('device:fault:view_all')
    if (actor?.userId && !hasViewAll) {
      where.reporter_id = actor.userId
    }

    // 一次拉回 status + fault_level，JS 端聚合（数据量不大）
    const rows = await DeviceFault.findAll({
      where,
      attributes: ['status', 'fault_level'],
      raw: true,
    })

    const s = { pending: 0, repairing: 0, approving: 0, closed: 0, urgent: 0, total: rows.length }
    for (const r of rows as any[]) {
      const st = typeof r.status === 'number' ? STATUS_MAP[r.status] : r.status
      if (st === '待派工') s.pending++
      else if (st === '维修中') s.repairing++
      else if (st === '待审批') s.approving++
      else if (st === '已关闭') s.closed++
      if ((r.fault_level === '紧急' || r.fault_level === 3)) s.urgent++
    }
    return s
  },

  /** 故障详情（含维修记录+图片） */
  async detail(id: number | string) {
    const record = await getFaultDetail(Number(id))
    if (!record) throw new AppError('故障记录不存在', 10002, 404)
    return record
  },

  /** 创建故障（自动编号 + 设备关联校验） */
  async create(body: any, actor?: any) {
    if (!body.device_id) throw new AppError('设备不能为空', 10001, 400)

    const device = await Device.findOne({ where: { device_id: body.device_id } })
    if (!device) throw new AppError('设备不存在', 10002, 404)

    const fault_no = await generateDeviceFaultNo()
    const record = await DeviceFault.create({
      fault_no,
      device_id: body.device_id,
      device_code: (device as any).device_code,
      device_name: (device as any).device_name,
      fault_level: body.fault_level || 1,
      fault_desc: body.fault_desc || '',
      impact_desc: body.impact_desc || '',
      fault_time: body.fault_time ? new Date(body.fault_time) : nowBeijingDate(),
      status: 0, // 新建=待派工
      reporter_id: actor?.userId || null,
      reporter_name: actor?.realName || actor?.username || null,
      remarks: body.remarks,
    } as any)
    return record
  },

  /** 指派维修人（状态 0→1）— 只允许指派给设备维护员 */
  async assign(id: number | string, body: any, actor?: any) {
    const fault = await DeviceFault.findOne({ where: { fault_id: Number(id) } })
    if (!fault) throw new AppError('故障记录不存在', 10002, 404)

    if (fault.getDataValue('status') !== 0) {
      throw new AppError('当前状态不可指派维修人', 20001, 409)
    }

    if (!body.assignee_id) throw new AppError('维修人不能为空', 10001, 400)

    // 校验被指派人必须是设备维护员
    const assignee = await User.findOne({
      where: { user_id: body.assignee_id },
      attributes: ['user_id', 'username'],
      include: [{ model: Role, as: 'role', attributes: ['role_code', 'role_name'] }],
    })
    if (!assignee) throw new AppError('被指派人不存在', 10002, 404)
    const assigneeRoleCode = (assignee as any).role?.role_code
    if (assigneeRoleCode !== 'MAINTENANCE') {
      throw new AppError('只能指派给"设备维护员"角色', 20001, 400)
    }

    await fault.update({
      status: 1,
      repairer_id: body.assignee_id,
      repairer_name: body.assignee_name || '',
      assigned_time: nowBeijingDate(),
    } as any)
    return fault
  },

  /** 提交维修结果（状态 1→2，事务：写维修记录） */
  async submitRepair(id: number | string, body: any, actor?: any) {
    const fault = await DeviceFault.findOne({ where: { fault_id: Number(id) } })
    if (!fault) throw new AppError('故障记录不存在', 10002, 404)

    if (fault.getDataValue('status') !== 1) {
      throw new AppError('当前状态不可提交维修结果', 20001, 409)
    }

    const t = await sequelize.transaction()
    try {
      // 前端字段名 → DeviceFaultRepair Model 字段
      const partsCost = Number(body.parts_cost ?? body.spare_parts_cost) || 0
      const laborCost = Number(body.labor_cost) || 0
      const totalCost = Number(body.total_cost) || partsCost + laborCost + (Number(body.outsource_cost ?? body.external_cost) || 0)
      const repairRecord = await DeviceFaultRepair.create({
        fault_id: Number(id),
        fault_cause: body.fault_cause || '',
        repair_plan: body.repair_solution || '',
        repair_detail: body.repair_process || body.repair_detail || '',
        spare_parts_used: body.spare_parts_used || body.spare_parts || [],
        spare_parts_cost: partsCost,
        labor_hours: Number(body.repair_hours ?? body.labor_hours) || 0,
        labor_rate: Number(body.hourly_rate ?? body.labor_rate) || 0,
        labor_cost: laborCost,
        external_cost: Number(body.outsource_cost ?? body.external_cost) || 0,
        total_cost: totalCost,
        repair_time: nowBeijingDate(),
        repair_user_id: actor?.userId || null,
        repair_user_name: actor?.realName || actor?.username || null,
      } as any, { transaction: t })

      // 计算维修成本并写入故障主表
      const cost = calcRepairCost(repairRecord)
      await fault.update({
        status: 2,
        repair_id: (repairRecord as any).repair_id,
        repair_time: nowBeijingDate(),
        total_cost: cost.total_cost,
        // 维修人登记（如果派工已设置则确认；若未派工但 actor 是维修人则补充）
        repairer_id: fault.getDataValue('repairer_id') ?? actor?.userId ?? null,
        repairer_name: fault.getDataValue('repairer_name') ?? actor?.realName ?? actor?.username ?? null,
        repair_start_time: nowBeijingDate(),
      } as any, { transaction: t })

      await t.commit()
      return await getFaultDetail(Number(id))
    } catch (err) {
      if (t && !(t as any).finished) { try { await t.rollback() } catch (_) { /* ignore */ } }
      throw err
    }
  },

  /** 审批维修结果（状态 2→3 已解决 或 →4 退回） */
  async approve(id: number | string, body: any, actor?: any) {
    const fault = await DeviceFault.findOne({ where: { fault_id: Number(id) } })
    if (!fault) throw new AppError('故障记录不存在', 10002, 404)

    if (fault.getDataValue('status') !== 2) {
      throw new AppError('当前状态不可审批', 20001, 409)
    }

    // 前端传 approve_result='通过'/'驳回'，兼容旧的 approved 布尔
    const result = body.approve_result
    const approved = typeof result === 'boolean' ? result
      : (result === '通过' || result === true || body.approved === true)
    if (approved !== true && approved !== false) {
      throw new AppError('必须指定审批结果（通过/驳回）', 10001, 400)
    }
    const approveRemark = body.approve_opinion !== undefined ? body.approve_opinion : (body.remarks || '')

    await fault.update({
      status: approved ? 3 : 1, // 3=已解决，退回=1=维修中
      approver_id: actor?.userId || null,
      approver_name: actor?.realName || actor?.username || null,
      approve_time: nowBeijingDate(),
      approve_remark: approveRemark,
      remarks: approveRemark || (fault as any).remarks,
    } as any)

    logger.info(`[DeviceFault] 故障审批: fault_id=${id}, approved=${approved}`)
    return await getFaultDetail(Number(id))
  },

  /** 关闭故障（任何未关闭状态都可手动关闭） */
  async close(id: number | string, body: any, actor?: any) {
    const fault = await DeviceFault.findOne({ where: { fault_id: Number(id) } })
    if (!fault) throw new AppError('故障记录不存在', 10002, 404)

    const s = fault.getDataValue('status')
    if (s === 3) {
      throw new AppError('故障已关闭，不可重复关闭', 20001, 409)
    }

    await fault.update({
      status: 3, // 已关闭
      closed_time: nowBeijingDate(),
      approver_id: actor?.userId || null,
      approver_name: actor?.realName || actor?.username || null,
      approve_remark: body.close_reason || body.approve_remark || '',
    } as any)
    return await getFaultDetail(Number(id))
  },

  /** 删除故障（只有报故障状态 + 无子维修记录可删） */
  async delete(id: number | string) {
    const fault = await DeviceFault.findOne({ where: { fault_id: Number(id) } })
    if (!fault) throw new AppError('故障记录不存在', 10002, 404)

    if (fault.getDataValue('status') !== 0) {
      throw new AppError('只有新建状态可以删除', 20001, 409)
    }

    const repairCount = await DeviceFaultRepair.count({ where: { fault_id: Number(id) } })
    if (repairCount > 0) throw new AppError('该故障存在维修记录，无法删除', 20001, 409)

    await fault.destroy()
    return true
  },

  /** 获取故障图片（故障图 + 维修图，均以 fault_id 为 doc_id） */
  async getImages(id: number | string) {
    const faultImages = await DeviceImage.findAll({
      where: { doc_type: 'fault', doc_id: Number(id) },
      order: [['sort_order', 'ASC']],
    })
    const repairImages = await DeviceImage.findAll({
      where: { doc_type: 'repair', doc_id: Number(id) },
      order: [['sort_order', 'ASC']],
    })
    return { fault_images: faultImages, repair_images: repairImages }
  },

  // ---------- uploadImage DB 操作 ----------

  /** 校验故障存在（事务内） */
  async assertFaultExists(faultId: number, transaction?: any) {
    const fault = await DeviceFault.findOne({ where: { fault_id: faultId }, transaction })
    if (!fault) throw new AppError('故障记录不存在', 10002, 404)
    return fault
  },

  /** 统计某类图片已有数量（doc_type: fault / repair） */
  async countFaultImages(faultId: number, docType = 'fault', transaction?: any) {
    return await DeviceImage.count({ where: { doc_type: docType, doc_id: faultId }, transaction })
  },

  /** 创建故障图片记录 */
  async createFaultImage(data: any, transaction?: any) {
    return await DeviceImage.create(data, { transaction })
  },

  /**
   * 按 image_id 删除单张图片（校验归属后删 DB 行）
   * 返回相对路径，供 Controller 删除物理文件
   */
  async deleteImage(faultId: number | string, imageId: number | string) {
    const idNum = Number(imageId)
    if (!Number.isFinite(idNum) || idNum <= 0) {
      throw new AppError('图片ID无效', 10002, 400)
    }
    const img = await DeviceImage.findOne({
      where: {
        image_id: idNum,
        doc_id: Number(faultId),
        doc_type: { [Op.in]: ['fault', 'repair'] },
      },
    })
    if (!img) throw new AppError('图片不存在或不属于该故障单', 10002, 404)

    const relPath = String(img.getDataValue('file_path') || '')
    await img.destroy()
    return relPath
  },
}

export default DeviceFaultService
