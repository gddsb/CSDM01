import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import {
  User, Role, Permission, OperationLog, Material,
  ProductionLine, Process, Device, DefectType,
  Order, ReportOrder, ReportProcess, ReportImage,
  ManpowerRecord, SystemConfig,
  RolePermission, Sequence, Customer,
  LineProcess, LineDevice, NumberRule, DefectImage,
  DictType, DictData, ProcessDefect, ProcessException,
  ProcessMaterial, DataDictionary,
  InspectionStandard, InspectionStandardItem,
  MicrobeInspection,
  ProductInspection,
  IncomingInspection,
  QcInspectionItem,
  QcInspectionSampleValue,
  Instrument,
} from './models/index.js'
import sequelize from './config/database.js'
import { logger } from './utils/logger.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const seedDataDir = path.join(__dirname, 'seed-data')

const seedOrder = [
  { name: 'Role', model: Role, label: '角色' },
  { name: 'Permission', model: Permission, label: '权限' },
  { name: 'RolePermission', model: RolePermission, label: '角色权限' },
  { name: 'User', model: User, label: '用户' },
  { name: 'Process', model: Process, label: '工序' },
  { name: 'Customer', model: Customer, label: '客户档案' },
  { name: 'Material', model: Material, label: '料品档案' },
  { name: 'ProductionLine', model: ProductionLine, label: '产线' },
  { name: 'Device', model: Device, label: '设备' },
  { name: 'LineProcess', model: LineProcess, label: '产线工序' },
  { name: 'LineDevice', model: LineDevice, label: '产线设备' },
  { name: 'DefectType', model: DefectType, label: '不良分类' },
  { name: 'DefectImage', model: DefectImage, label: '不良图片' },
  { name: 'DictType', model: DictType, label: '字典类型' },
  { name: 'DictData', model: DictData, label: '字典数据' },
  { name: 'Order', model: Order, label: '生产订单' },
  { name: 'ReportOrder', model: ReportOrder, label: '生产报工单' },
  { name: 'ReportProcess', model: ReportProcess, label: '报工工序' },
  { name: 'ProcessDefect', model: ProcessDefect, label: '工序不良' },
  { name: 'ProcessMaterial', model: ProcessMaterial, label: '工序物料' },
  { name: 'ProcessException', model: ProcessException, label: '异常工时记录' },
  { name: 'ManpowerRecord', model: ManpowerRecord, label: '人员投入' },
  { name: 'ReportImage', model: ReportImage, label: '报工图片' },
  { name: 'SystemConfig', model: SystemConfig, label: '系统配置' },
  { name: 'Sequence', model: Sequence, label: '序列号' },
  { name: 'NumberRule', model: NumberRule, label: '编码规则' },
  { name: 'Instrument', model: Instrument, label: '检测仪器' },
  { name: 'InspectionStandard', model: InspectionStandard, label: '检验标准主表' },
  { name: 'InspectionStandardItem', model: InspectionStandardItem, label: '检验标准子表' },
  { name: 'IncomingInspection', model: IncomingInspection, label: '来料检验主表' },
  { name: 'ProductInspection', model: ProductInspection, label: '成品检验主表' },
  { name: 'MicrobeInspection', model: MicrobeInspection, label: '微生物检验主表' },
  // 阶段5.4：统一使用新统一子表 + 样品测量值表（替代三旧子表）
  { name: 'QcInspectionItem', model: QcInspectionItem, label: '统一检验子表（来料/产品/微生物）' },
  { name: 'QcInspectionSampleValue', model: QcInspectionSampleValue, label: '检验样品测量值' },
  { name: 'DataDictionary', model: DataDictionary, label: '数据字典' },
  { name: 'OperationLog', model: OperationLog, label: '操作日志' },
]

function loadSeedData(name) {
  const filePath = path.join(seedDataDir, `${name}.json`)
  if (!fs.existsSync(filePath)) {
    return []
  }
  try {
    const content = fs.readFileSync(filePath, 'utf-8')
    return JSON.parse(content)
  } catch (err) {
    logger.info(`    ⚠️  读取 ${name}.json 失败: ${err.message}`)
    return []
  }
}

async function seed() {
  try {
    logger.info('🔄 开始同步数据库表（force: true）...')
    await sequelize.sync({ force: true })
    logger.info('✅ 数据库表同步完成\n')

    const counts = {}

    for (const { name, model, label } of seedOrder) {
      const data = loadSeedData(name)
      if (data.length === 0) {
        logger.info(`📌 ${label}... 无数据，跳过`)
        counts[name] = 0
        continue
      }

      logger.info(`📌 ${label}...`)
      try {
        await model.bulkCreate(data, { validate: false })
        logger.info(`✅ ${label}创建完成（${data.length}条）`)
        counts[name] = data.length
      } catch (err) {
        logger.info(`❌ ${label}创建失败: ${err.message}`)
        logger.info(`   尝试逐条插入...`)
        let success = 0
        for (const item of data) {
          try {
            await model.create(item, { validate: false })
            success++
          } catch (itemErr) {
            logger.info(`   ⚠️  跳过一条数据: ${itemErr.message}`)
          }
        }
        logger.info(`✅ ${label}创建完成（${success}/${data.length}条）`)
        counts[name] = success
      }
    }

    logger.info('\n🎉 种子数据初始化完成！')
    for (const { name, label } of seedOrder) {
      if (counts[name] > 0) {
        logger.info(`   - ${label}：${counts[name]} 条`)
      }
    }
    logger.info(`\n   默认登录账号：admin / 123456`)

    await sequelize.close()
    process.exit(0)
  } catch (err) {
    logger.error('❌ 种子数据初始化失败:', err)
    try {
      await sequelize.close()
    } catch (err) {
        logger.warn('[SilentCatch] 静默异常被捕获', err?.message)
    }
    process.exit(1)
  }
}

seed()
