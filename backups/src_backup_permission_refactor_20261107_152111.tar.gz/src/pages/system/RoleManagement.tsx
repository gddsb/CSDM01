import ResizableTable from '../../components/ResizableTable'
import React, { useState, useEffect, useMemo } from 'react'
import { Table, Tag, Button, Modal, Form, Input, Select, Space, Tree, InputNumber, Popconfirm, Row, Col, Typography, Spin, Switch, Tabs } from 'antd'
import {
  SafetyCertificateOutlined, ApartmentOutlined,
  PlusOutlined, ReloadOutlined, SafetyOutlined,
} from '@ant-design/icons'
import ThreeSectionPage from '../../components/ThreeSectionPage'
import type { FilterItem, StatItem } from '../../components/ThreeSectionPage'
import api from '../../utils/api'
import { useMessage, useApp } from '../../contexts/AppContext'

const { Text } = Typography

const statusOptions = [{ label: '启用', value: '启用' }, { label: '禁用', value: '禁用' }]
const typeOptions = [{ label: '系统默认', value: '系统默认' }, { label: '可选', value: '可选' }]

// 将树形权限列表扁平化为数组
function flattenTree(nodes, result = []) {
  nodes.forEach(n => {
    result.push(n)
    if (n.children && n.children.length > 0) {
      flattenTree(n.children, result)
    }
  })
  return result
}

// 根据权限码前缀返回 platform tag 样式
function platformTagStyle(code: string): { color: string; label: string } | null {
  if (!code) return null
  if (code.startsWith('pc:'))       return { color: 'blue',   label: 'PC' }
  if (code.startsWith('mobile:'))   return { color: 'green',  label: '移动' }
  if (code.startsWith('all:'))      return { color: 'default', label: 'All' }
  return null // 旧格式无前缀码
}

// 根据 perm_code 判断所属 platform
function codePlatform(code: string): 'pc' | 'mobile' | 'allp' | 'legacy' {
  if (code.startsWith('pc:'))     return 'pc'
  if (code.startsWith('mobile:')) return 'mobile'
  if (code.startsWith('all:'))    return 'allp'
  return 'legacy' // 旧码 device:fault:view 等 → 归入 "全部" Tab
}

// 根据扁平权限列表构建树形结构（支持 platform 过滤 + 节点彩色前缀 tag）
function buildPermissionTree(permissions, platformFilter?: string) {
  // 如果后端返回的已经是树形结构，先扁平化
  const hasChildren = permissions.some(p => p.children && p.children.length > 0)
  let flatPerms = hasChildren ? flattenTree(permissions) : permissions

  // platform 过滤：只保留符合当前 Tab 范围的节点
  //   'all'     → 全部不过滤
  //   'pc'      → pc 前缀 + 旧码（legacy 归入 pc 兼容旧前端）
  //   'mobile'  → mobile 前缀
  //   'allp'    → all 前缀
  if (platformFilter && platformFilter !== 'all') {
    flatPerms = flatPerms.filter(p => {
      const plat = codePlatform(p.perm_code)
      if (platformFilter === 'pc')      return plat === 'pc' || plat === 'legacy'
      if (platformFilter === 'mobile')  return plat === 'mobile'
      if (platformFilter === 'allp')    return plat === 'allp'
      return true
    })
  }

  const map = new Map()
  const roots = []
  flatPerms.forEach(p => {
    const isButton = p.type === 'button'
    const tagInfo = platformTagStyle(p.perm_code)
    const titleNode = (
      <span>
        {tagInfo && <Tag color={tagInfo.color} style={{ marginRight: 6, fontSize: 11, padding: '0 4px', lineHeight: '18px' }}>{tagInfo.label}</Tag>}
        {isButton && !tagInfo && <Tag color="purple" style={{ marginRight: 6, fontSize: 11, padding: '0 4px', lineHeight: '18px' }}>按钮</Tag>}
        <span>{p.perm_name}</span>
        <Text type="secondary" style={{ marginLeft: 8, fontSize: 12 }}>{p.perm_code}</Text>
      </span>
    )
    map.set(p.perm_id, { title: titleNode, key: p.perm_id, children: [], _raw: p })
  })
  flatPerms.forEach(p => {
    const node = map.get(p.perm_id)
    if (!p.parent_id || p.parent_id === 0) {
      roots.push(node)
    } else {
      const parent = map.get(p.parent_id)
      if (parent) parent.children.push(node)
      else roots.push(node)
    }
  })
  const sortNodes = (nodes) => {
    nodes.sort((a, b) => (a._raw?.sort_order || 0) - (b._raw?.sort_order || 0))
    nodes.forEach(n => sortNodes(n.children))
    nodes.forEach(n => { delete n._raw })
    return nodes
  }
  return sortNodes(roots)
}

export default function RoleManagement() {
  const message = useMessage()
  const { hasPermission } = useApp()
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(false)
  const [total, setTotal] = useState(0)
  const [editing, setEditing] = useState(null)
  const [modalVisible, setModalVisible] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [form] = Form.useForm()

  // 筛选输入态
  const [keywordInput, setKeywordInput] = useState('')
  const [statusInput, setStatusInput] = useState(undefined)
  // 已应用的查询条件
  const [query, setQuery] = useState({ page: 1, pageSize: 30, keyword: '', status: undefined })

  // 权限配置
  const [permModalVisible, setPermModalVisible] = useState(false)
  const [permRole, setPermRole] = useState(null)
  const [permissions, setPermissions] = useState([])
  const [checkedKeys, setCheckedKeys] = useState<React.Key[] | { checked: React.Key[]; halfChecked: React.Key[] }>([])
  const [permLoading, setPermLoading] = useState(false)
  const [permSaving, setPermSaving] = useState(false)
  const [permPlatformTab, setPermPlatformTab] = useState<string>('all')

  const defaultCount = data.filter(r => r.type === '系统默认').length
  const optionalCount = data.filter(r => r.type === '可选').length

  const stats: StatItem[] = [
    { label: '角色总数', value: total, icon: <SafetyCertificateOutlined />, color: 'var(--color-primary)' },
    { label: '系统默认角色', value: defaultCount, icon: <ApartmentOutlined />, color: 'var(--color-warning)' },
    { label: '可选角色', value: optionalCount, icon: <SafetyOutlined />, color: 'var(--color-success)' },
  ]

  const treeData = useMemo(() => buildPermissionTree(permissions, permPlatformTab), [permissions, permPlatformTab])

  // 获取角色列表
  useEffect(() => {
    let cancelled = false
    const run = async () => {
      setLoading(true)
      try {
        const params: Record<string, unknown> = { page: query.page, pageSize: query.pageSize }
        if (query.keyword) params.keyword = query.keyword
        if (query.status !== undefined && query.status !== null) params.status = query.status
        const res = await api.get('/system/roles', { params })
        if (cancelled) return
        const list = res.data || []
        setData(list)
        setTotal(res.total || list.length)
      } catch (err) {
        if (!cancelled) {
          message.error(err.message || '获取角色列表失败')
          setData([])
          setTotal(0)
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    run()
    return () => { cancelled = true }
  }, [query])

  const refresh = () => setQuery(q => ({ ...q }))

  const handleSearch = () => {
    setQuery(q => ({ ...q, page: 1, keyword: keywordInput, status: statusInput }))
  }

  const handleReset = () => {
    setKeywordInput('')
    setStatusInput(undefined)
    setQuery(q => ({ ...q, page: 1, keyword: '', status: undefined }))
  }

  const handleAdd = () => {
    setEditing(null)
    setModalVisible(true)
  }

  const handleEdit = (record) => {
    if (record.role_code === 'SUPER_ADMIN' || record.is_system_default === 1) {
      message.warning('系统默认角色禁止编辑')
      return
    }
    setEditing(record)
    setModalVisible(true)
  }

  // Modal 打开动画结束后再设置表单值（配合 destroyOnHidden + preserve={false}）
  const handleAfterOpenChange = (open) => {
    if (!open) return
    if (editing) {
      form.setFieldsValue({
        role_name: editing.role_name,
        role_code: editing.role_code,
        type: editing.type,
        scope: editing.scope,
        sort_order: editing.sort_order,
        status: editing.status,
        description: editing.description,
        is_system_default: !!editing.is_system_default,
      })
    } else {
      form.resetFields()
      form.setFieldsValue({ status: '启用', type: '可选', sort_order: 0, is_system_default: false })
    }
  }

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields()
      setSubmitting(true)
      const payload = { ...values }
      // Switch 布尔值转 0/1
      payload.is_system_default = payload.is_system_default ? 1 : 0
      if (editing) {
        const res = await api.put(`/system/roles/${editing.role_id}`, payload)
        message.success(res.message || '角色编辑成功')
      } else {
        const res = await api.post('/system/roles', payload)
        message.success(res.message || '角色新增成功')
      }
      setModalVisible(false)
      refresh()
    } catch (e) {
      if (e?.errorFields) return
      message.error(e.message || '操作失败')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (record) => {
    if (record.role_code === 'SUPER_ADMIN' || record.is_system_default === 1) {
      message.warning('系统默认角色禁止删除')
      return
    }
    try {
      const res = await api.delete(`/system/roles/${record.role_id}`)
      message.success(res.message || '删除成功')
      refresh()
    } catch (err) {
      message.error(err.message || '删除失败')
    }
  }

  // 打开权限配置 Modal
  const handleConfigPerms = async (record) => {
    if (record.role_code === 'SUPER_ADMIN' || record.is_system_default === 1) {
      message.warning('系统默认角色禁止修改权限')
      return
    }
    setPermRole(record)
    setPermModalVisible(true)
    setCheckedKeys([])
    setPermPlatformTab('all')  // 打开时重置到 "全部"
    setPermLoading(true)
    try {
      // 并行加载所有权限和当前角色已有权限
      const [allRes, roleRes] = await Promise.all([
        api.get('/system/permissions'),
        api.get(`/system/roles/${record.role_id}/permissions`),
      ])
      setPermissions(allRes.data || [])
      setCheckedKeys(roleRes.data || [])
    } catch (err) {
      message.error(err.message || '加载权限数据失败')
    } finally {
      setPermLoading(false)
    }
  }

  const handleSavePerms = async () => {
    if (!permRole) return
    setPermSaving(true)
    try {
      const keys = Array.isArray(checkedKeys) ? checkedKeys : checkedKeys.checked
      const res = await api.put(`/system/roles/${permRole.role_id}/permissions`, { perm_ids: keys })
      message.success(res.message || '权限分配成功')
      setPermModalVisible(false)
    } catch (err) {
      message.error(err.message || '权限保存失败')
    } finally {
      setPermSaving(false)
    }
  }

  const filters: FilterItem[] = [
    { type: 'input', placeholder: '搜索角色名称/编码', col: { span: 6 }, value: keywordInput, onChange: (e) => setKeywordInput((e as React.ChangeEvent<HTMLInputElement>).target.value) },
    {
      type: 'select', placeholder: '状态筛选', col: { span: 6 },
      options: statusOptions, value: statusInput, onChange: v => setStatusInput(v),
    },
  ]

  const columns = [
    { title: '角色名称', dataIndex: 'role_name', key: 'role_name' },
    { title: '角色编码', dataIndex: 'role_code', key: 'role_code' },
    {
      title: '类型', dataIndex: 'type', key: 'type', width: 100,
      render: v => v === '系统默认' ? <Tag color="blue">{v}</Tag> : <Tag color="orange">{v}</Tag>,
    },
    {
      title: '系统默认', dataIndex: 'is_system_default', key: 'is_system_default', width: 90,
      render: v => v === 1 || v === true ? <Tag color="blue">是</Tag> : <Tag>否</Tag>,
    },
    { title: '权限范围', dataIndex: 'scope', key: 'scope', ellipsis: true },
    {
      title: '状态', dataIndex: 'status', key: 'status', width: 80,
      render: v => v === '启用' ? <Tag color="green">启用</Tag> : <Tag color="red">禁用</Tag>,
    },
    { title: '排序', dataIndex: 'sort_order', key: 'sort_order', width: 60 },
    {
      title: '操作', key: 'action',
      render: (_, record) => {
        const isProtected = record.role_code === 'SUPER_ADMIN' || record.is_system_default === 1
        return (
          <Space size="small">
            <Button
              type="link"
              size="small"
              disabled={isProtected}
              onClick={() => handleConfigPerms(record)}
            >
              配置权限
            </Button>
            {hasPermission('system:role:update') && (
              <Button
                type="link"
                size="small"
                disabled={isProtected}
                onClick={() => handleEdit(record)}
              >
                编辑
              </Button>
            )}
            {hasPermission('system:role:delete') && (
              <Popconfirm
                title="确认删除该角色？"
                onConfirm={() => handleDelete(record)}
                okText="确认"
                cancelText="取消"
                disabled={isProtected}
              >
                <Button type="link" size="small" danger disabled={isProtected}>删除</Button>
              </Popconfirm>
            )}
          </Space>
        )
      },
    },
  ]

  return (
    <>
      <ThreeSectionPage
        title="角色权限"
        breadcrumbs="系统管理 / 角色权限"
        stats={stats}
        filters={filters}
        onSearch={handleSearch}
        onReset={handleReset}
        actions={
          <Space>
            <Button type="primary" icon={<PlusOutlined />} onClick={handleAdd}>新增角色</Button>
          </Space>
        }
        table={
          <ResizableTable tableKey="pages_system_RoleManagement"             columns={columns}
            dataSource={data}
            rowKey="role_id"
            size="small"
            loading={loading}
            pagination={{
              current: query.page,
              pageSize: query.pageSize,
              total,
              showSizeChanger: true,
              showTotal: t => `共 ${t} 条`,
              onChange: (p, ps) => setQuery(q => ({ ...q, page: p, pageSize: ps })),
            }}
          />
        }
      />
      <Modal
        title={editing ? '编辑角色' : '新增角色'}
        open={modalVisible}
        onOk={handleSubmit}
        confirmLoading={submitting}
        onCancel={() => setModalVisible(false)}
        afterOpenChange={handleAfterOpenChange}
        okText="保存"
        cancelText="取消"
        width={560}
        destroyOnHidden
      >
        <Form form={form} layout="vertical" className="compact-form" preserve={false}>
          <Row gutter={12}>
            <Col span={12}>
              <Form.Item name="role_name" label="角色名称" rules={[{ required: true, message: '请输入角色名称' }]}>
                <Input placeholder="请输入角色名称" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="role_code" label="角色编码" rules={[{ required: true, message: '请输入角色编码' }]}>
                <Input placeholder="请输入角色编码" disabled={!!editing} />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={12}>
            <Col span={8}>
              <Form.Item name="type" label="类型">
                <Select placeholder="请选择类型" options={typeOptions} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="status" label="状态" rules={[{ required: true, message: '请选择状态' }]}>
                <Select placeholder="请选择状态" options={statusOptions} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="sort_order" label="排序号">
                <InputNumber min={0} style={{ width: '100%' }} placeholder="排序号" />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={12}>
            <Col span={16}>
              <Form.Item name="scope" label="权限范围">
                <Input placeholder="请输入权限范围说明" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="is_system_default" label="系统默认" valuePropName="checked">
                <Switch
                  checkedChildren="是"
                  unCheckedChildren="否"
                  disabled={!!editing && !!editing.is_system_default}
                />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={12}>
            <Col span={24}>
              <Form.Item name="description" label="描述">
                <Input.TextArea placeholder="请输入描述" rows={2} />
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </Modal>
      <Modal
        title={`配置权限 - ${permRole?.role_name || ''}`}
        open={permModalVisible}
        onOk={handleSavePerms}
        confirmLoading={permSaving}
        onCancel={() => setPermModalVisible(false)}
        okText="保存权限"
        cancelText="取消"
        width={560}
        destroyOnHidden
      >
        <Spin spinning={permLoading}>
          <Text type="secondary" style={{ display: 'block', marginBottom: 12 }}>
            勾选该角色拥有的权限，保存后立即生效。
          </Text>
          <Tabs
            activeKey={permPlatformTab}
            onChange={setPermPlatformTab}
            size="small"
            style={{ marginBottom: 8 }}
            items={[
              { key: 'all',   label: '全部' },
              { key: 'pc',    label: <span><Tag color="blue" style={{ marginRight: 4, fontSize: 11, padding: '0 4px', lineHeight: '16px' }}>PC</Tag> PC端</span> },
              { key: 'mobile',label: <span><Tag color="green" style={{ marginRight: 4, fontSize: 11, padding: '0 4px', lineHeight: '16px' }}>移动</Tag> 移动端</span> },
              { key: 'allp',  label: <span><Tag color="default" style={{ marginRight: 4, fontSize: 11, padding: '0 4px', lineHeight: '16px' }}>All</Tag> 通用</span> },
            ]}
          />
          <Tree
            checkable
            defaultExpandAll
            treeData={treeData}
            checkedKeys={checkedKeys}
            onCheck={(keys) => setCheckedKeys(keys)}
            style={{ maxHeight: 440, overflow: 'auto' }}
          />
        </Spin>
      </Modal>
    </>
  )
}
