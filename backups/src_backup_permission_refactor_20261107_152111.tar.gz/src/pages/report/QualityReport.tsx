import ResizableTable from '../../components/ResizableTable'
import React, { useState, useMemo, useEffect } from 'react'
import { Table, Tag, Button, Select, Input, Space, Row, Col, Progress, DatePicker, Card, Spin, message, Alert } from 'antd'
import {
  ExperimentOutlined, ExportOutlined, SearchOutlined, ReloadOutlined,
  CheckCircleOutlined, CloseCircleOutlined, SafetyCertificateOutlined,
  RiseOutlined
} from '@ant-design/icons'
import ThreeSectionPage from '../../components/ThreeSectionPage'
import type { FilterItem, StatItem } from '../../components/ThreeSectionPage'
import { formatDateTime } from '../../utils'
import api, { extractList } from '../../utils/api'
import { MONTH_QUICK_OPTIONS, getMonthRange, validateRange, getThisMonth } from '../../utils/monthQuick'
import dayjs from 'dayjs'
import {
  microbeInspections as mockMicrobe,
  envInspections as mockEnv,
  complaints as mockComplaints,
} from '../../mock/data'

const { RangePicker } = DatePicker

const resultColorMap = {
  '合格': 'success',
  '不合格': 'error',
  null: 'default',
}

export default function QualityReport() {
  const [typeFilter, setTypeFilter] = useState<string>('all')
  const [resultFilter, setResultFilter] = useState<string | undefined>(undefined)
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(false)
  const [incomingInspections, setIncomingInspections] = useState<any[]>([])
  const [finishedInspections, setFinishedInspections] = useState<any[]>([])
  const [microbeInspections, setMicrobeInspections] = useState<any[]>([])
  const [envInspections, setEnvInspections] = useState<any[]>([])
  const [complaints, setComplaints] = useState<any[]>([])
  const [dateRange, setDateRange] = useState<any>(getThisMonth())
  const [monthQuick, setMonthQuick] = useState<string>('this_month')
  const [rangeWarn, setRangeWarn] = useState(false)

  const loadData = async () => {
    setLoading(true)
    if (dateRange) {
      const check = validateRange(dateRange)
      if (!check.ok) {
        message.warning(check.msg)
        setLoading(false)
        return
      }
      setRangeWarn(!!check.warn)
    } else {
      setRangeWarn(false)
    }
    try {
      const [incRes, finRes] = await Promise.all([
        api.get('/basic/incoming-inspections', { params: { pageSize: 200, ...(dateRange ? { dateStart: dateRange[0].format('YYYY-MM-DD'), dateEnd: dateRange[1].format('YYYY-MM-DD') } : {}) } }),
        api.get('/basic/product-inspections', { params: { pageSize: 200, ...(dateRange ? { dateStart: dateRange[0].format('YYYY-MM-DD'), dateEnd: dateRange[1].format('YYYY-MM-DD') } : {}) } }),
      ])
      if (incRes.success && incRes.data) {
        setIncomingInspections(extractList(incRes.data).map((i: any) => ({
          ...i,
          inspection_id: i.incoming_id || i.inspection_id,
          inspection_no: i.incoming_no || i.inspection_no,
          inspector_name: i.inspector_name || i.inspector || '',
          result: i.final_result || i.result,
          status: i.status,
        })))
      }
      if (finRes.success && finRes.data) {
        setFinishedInspections(extractList(finRes.data).map((i: any) => ({
          ...i,
          inspection_id: i.product_id || i.inspection_id,
          inspection_no: i.product_no || i.inspection_no,
          work_order_no: i.report_order_no || i.work_order_no,
          inspector_name: i.inspector_name || i.inspector || '',
          result: i.final_result || i.result,
          status: i.status,
        })))
      }
      setMicrobeInspections(mockMicrobe)
      setEnvInspections(mockEnv)
      setComplaints(mockComplaints)
    } catch (err: any) {
      message.error(err.message || '加载数据失败')
    } finally {
      setLoading(false)
      setRangeWarn(false)
    }
  }

  const handleMonthQuick = (v: string) => {
    setMonthQuick(v)
    const range = getMonthRange(v)
    setDateRange(range)
  }
  const handleRangeChange = (v: any) => {
    setMonthQuick(undefined)
    setDateRange(v)
  }

  useEffect(() => {
    loadData()
  }, [])

  // 汇总所有检验数据
  const allInspections = useMemo(() => {
    const incoming = incomingInspections.map(i => ({
      ...i,
      inspection_category: '来料检验',
      batch_no: i.internal_batch_no,
      target: i.supplier_name,
      qty: i.quantity,
    }))
    const finished = finishedInspections.map(i => ({
      ...i,
      inspection_category: '成品检验',
      batch_no: i.work_order_no,
      target: i.work_order_no,
      qty: null,
    }))
    const microbe = microbeInspections.map(i => ({
      ...i,
      inspection_category: '微生物检验',
      batch_no: i.work_order_no || i.incoming_id,
      target: i.object_type,
      qty: null,
    }))
    const env = envInspections.map(i => ({
      ...i,
      inspection_category: '环境检验',
      batch_no: i.inspection_no,
      target: i.area_name,
      qty: null,
    }))
    return [...incoming, ...finished, ...microbe, ...env]
  }, [incomingInspections, finishedInspections, microbeInspections, envInspections])

  const filtered = allInspections.filter((r: any) => {
    const matchType = typeFilter === 'all' || r.inspection_category === typeFilter
    const matchResult = !resultFilter || r.result === resultFilter
    const matchSearch = !search || (r.inspection_no && r.inspection_no.toLowerCase().includes(search.toLowerCase()))
    let matchDate = true
    if (dateRange && dateRange[0] && dateRange[1] && r.inspection_time) {
      const t = dayjs(r.inspection_time)
      matchDate = t.isAfter(dateRange[0].subtract(1, 'day')) && t.isBefore(dateRange[1].add(1, 'day'))
    }
    return matchType && matchResult && matchSearch && matchDate
  })

  // 统计
  const totalInspections = filtered.length
  const passCount = filtered.filter((r: any) => r.result === '合格').length
  const failCount = filtered.filter((r: any) => r.result === '不合格').length
  const pendingCount = filtered.filter((r: any) => r.result === null || r.result === undefined).length
  const passRate = totalInspections > 0 ? ((passCount / (passCount + failCount || 1)) * 100).toFixed(1) : '0.0'
  const complaintCount = complaints.length

  const stats: StatItem[] = [
    { label: '检验总数', value: totalInspections, icon: <ExperimentOutlined />, color: 'var(--color-primary)' },
    { label: '合格数', value: passCount, icon: <CheckCircleOutlined />, color: 'var(--color-success)' },
    { label: '不合格数', value: failCount, icon: <CloseCircleOutlined />, color: 'var(--color-error)' },
    { label: '检验中', value: pendingCount, icon: <SafetyCertificateOutlined />, color: 'var(--color-warning)' },
    { label: '合格率', value: `${passRate}%`, icon: <RiseOutlined />, color: '#9C27B0' },
    { label: '客诉数', value: complaintCount, icon: <CloseCircleOutlined />, color: '#E91E63' },
  ]

  // 按检验类别汇总
  const categorySummary = useMemo(() => {
    const categories = ['来料检验', '成品检验', '微生物检验', '环境检验']
    return categories.map(cat => {
      const items = allInspections.filter(i => i.inspection_category === cat)
      const pass = items.filter(i => i.result === '合格').length
      const fail = items.filter(i => i.result === '不合格').length
      const pending = items.filter(i => i.result === null).length
      const rate = (pass + fail) > 0 ? ((pass / (pass + fail)) * 100).toFixed(1) : '-'
      return { category: cat, total: items.length, pass, fail, pending, pass_rate: rate }
    })
  }, [allInspections])

  const columns = [
    { title: '检验编号', dataIndex: 'inspection_no', key: 'inspection_no', width: 160, fixed: 'left' as const },
    { title: '检验类别', dataIndex: 'inspection_category', key: 'inspection_category', width: 100, render: v => <Tag color="blue">{v}</Tag> },
    { title: '检验对象', dataIndex: 'target', key: 'target', width: 140 },
    { title: '批次/工单号', dataIndex: 'batch_no', key: 'batch_no', width: 160 },
    { title: '物料名称', dataIndex: 'material_name', key: 'material_name', width: 120, render: v => v || '-' },
    { title: '标准名称', dataIndex: 'standard_name', key: 'standard_name', width: 180, render: v => v || '-' },
    { title: '数量', dataIndex: 'qty', key: 'qty', width: 80, render: v => v ? v.toLocaleString() : '-' },
    { title: '检验结果', dataIndex: 'result', key: 'result', width: 90, render: v => v ? <Tag color={resultColorMap[v]}>{v}</Tag> : <Tag>检验中</Tag> },
    { title: '处理方式', dataIndex: 'handle_type', key: 'handle_type', width: 90, render: v => v || '-' },
    { title: '检验人', dataIndex: 'inspector_name', key: 'inspector_name', width: 90 },
    { title: '检验时间', dataIndex: 'inspection_time', key: 'inspection_time', width: 160, render: v => formatDateTime(v) },
    { title: '状态', dataIndex: 'status', key: 'status', width: 90, render: v => <Tag color={v === '已完成' ? 'success' : 'processing'}>{v}</Tag> },
  ]

  return (
    <ThreeSectionPage
      title="质量报表"
      breadcrumbs="报表中心 / 质量报表"
      stats={stats}
      actions={<Button icon={<ExportOutlined />}>导出Excel</Button>}
      table={
        <Spin spinning={loading} tip="加载中...">
          <div>
          {/* 按类别汇总 */}
          <Row gutter={12} style={{ marginBottom: 12 }}>
            {categorySummary.map((cs, i) => (
              <Col key={i} span={6}>
                <Card size="small" style={{ borderRadius: 8 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 8 }}>{cs.category}</div>
                  <Row gutter={8}>
                    <Col span={6}>
                      <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>总数</div>
                      <div style={{ fontSize: 18, fontWeight: 700 }}>{cs.total}</div>
                    </Col>
                    <Col span={6}>
                      <div style={{ fontSize: 11, color: 'var(--color-success)' }}>合格</div>
                      <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--color-success)' }}>{cs.pass}</div>
                    </Col>
                    <Col span={6}>
                      <div style={{ fontSize: 11, color: 'var(--color-error)' }}>不合格</div>
                      <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--color-error)' }}>{cs.fail}</div>
                    </Col>
                    <Col span={6}>
                      <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>合格率</div>
                      <div style={{ fontSize: 18, fontWeight: 700 }}>{cs.pass_rate === '-' ? '-' : `${cs.pass_rate}%`}</div>
                    </Col>
                  </Row>
                  {cs.pass_rate !== '-' && (
                    <Progress
                      percent={parseFloat(cs.pass_rate)}
                      size="small"
                      strokeColor={parseFloat(cs.pass_rate) >= 95 ? 'var(--color-success)' : parseFloat(cs.pass_rate) >= 85 ? 'var(--color-warning)' : 'var(--color-error)'}
                      style={{ marginTop: 8, marginBottom: 0 }}
                    />
                  )}
                </Card>
              </Col>
            ))}
          </Row>

          <Row gutter={[12, 8]} style={{ marginBottom: 12 }}>
            <Col span={6}>
              <Input
                placeholder="搜索检验编号"
                allowClear
                prefix={<SearchOutlined />}
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </Col>
            <Col span={5}>
              <Select
                placeholder="检验类别"
                allowClear
                style={{ width: '100%' }}
                value={typeFilter}
                onChange={setTypeFilter}
                options={[
                  { label: '全部', value: 'all' },
                  { label: '来料检验', value: '来料检验' },
                  { label: '成品检验', value: '成品检验' },
                  { label: '微生物检验', value: '微生物检验' },
                  { label: '环境检验', value: '环境检验' },
                ]}
              />
            </Col>
            <Col span={5}>
              <Select
                placeholder="检验结果"
                allowClear
                style={{ width: '100%' }}
                value={resultFilter}
                onChange={setResultFilter}
                options={[
                  { label: '合格', value: '合格' },
                  { label: '不合格', value: '不合格' },
                ]}
              />
            </Col>
            <Col span={4}>
              <Select
                placeholder="快速选择月份"
                allowClear
                style={{ width: '100%' }}
                value={monthQuick || undefined}
                onChange={handleMonthQuick}
                options={MONTH_QUICK_OPTIONS}
              />
            </Col>
            <Col span={6}>
              <RangePicker style={{ width: '100%' }} value={dateRange} onChange={handleRangeChange} />
            </Col>
            <Col>
              <Space>
                <Button type="primary" icon={<SearchOutlined />} onClick={loadData}>查询</Button>
                <Button icon={<ReloadOutlined />} onClick={() => { setSearch(''); setTypeFilter('all'); setResultFilter(undefined); setMonthQuick('this_month'); setDateRange(getThisMonth()); loadData() }}>重置</Button>
              </Space>
            </Col>
          </Row>
          {rangeWarn && (
            <Alert type="warning" showIcon style={{ marginBottom: 12 }}
              message="查询跨度时间较长，后台需要较长时间执行查询，可能造成页面假死状态" />
          )}
          <ResizableTable tableKey="pages_report_QualityReport"             columns={columns}
            dataSource={filtered}
            rowKey={(r) => r.inspection_id}
            size="small"
            scroll={{ x: 1600 }}
            pagination={{ pageSize: 30, showSizeChanger: true, showTotal: t => `共 ${t} 条` }}
          />
          </div>
        </Spin>
      }
    />
  )
}
