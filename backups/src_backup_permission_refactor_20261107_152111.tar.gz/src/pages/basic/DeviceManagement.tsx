import ResizableTable from '../../components/ResizableTable'
import React, { useState, useEffect, useCallback } from 'react'
import { Table, Tag, Button, Drawer, Space, Modal, Form, Input, Select, Popconfirm, Descriptions, Row, Col } from 'antd'
import {
  ToolOutlined, PlayCircleOutlined, WarningOutlined, SafetyCertificateOutlined,
  PlusOutlined, EyeOutlined, ReloadOutlined,
} from '@ant-design/icons'
import ThreeSectionPage, { ActionButtons } from '../../components/ThreeSectionPage'
import type { FilterItem, StatItem } from '../../components/ThreeSectionPage'
import api from '../../utils/api'
import { useMessage, useApp } from '../../contexts/AppContext'

// 设备状态标签颜色映射（与后端 Device 模型一致：运行=1, 停用=0, 维修=2）
const statusColorMap = { '正常': 'green', '维修': 'orange', '停用': 'red' }
const statusOptions = ['正常', '维修', '停用'].map(s => ({ label: s, value: s }))
const specialOptions = [{ label: '是', value: 1 }, { label: '否', value: 0 }]

export default function DeviceManagement() {
  const message = useMessage()
  const { hasPermission } = useApp()
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(false)
  const [total, setTotal] = useState(0)
  const [detailOpen, setDetailOpen] = useState(false)
  const [current, setCurrent] = useState(null)
  const [editing, setEditing] = useState(null)
  const [modalVisible, setModalVisible] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [form] = Form.useForm()

  // 筛选输入态
  const [keywordInput, setKeywordInput] = useState('')
  const [statusInput, setStatusInput] = useState([1, 2, 0])
  const [typeInput, setTypeInput] = useState(undefined)
  const [specialInput, setSpecialInput] = useState(undefined)
  // 已应用的查询条件
  const [query, setQuery] = useState({ page: 1, pageSize: 30, keyword: '', status: [1, 2, 0], device_type: undefined, is_special: undefined })

  const runningCount = data.filter(d => d.status === '正常').length
  const faultCount = data.filter(d => d.status === '维修').length
  const specialCount = data.filter(d => d.is_special === true || d.is_special === 1).length

  const stats: StatItem[] = [
    { label: '设备总数', value: total, icon: <ToolOutlined />, color: 'var(--color-primary)' },
    { label: '正常', value: runningCount, icon: <PlayCircleOutlined />, color: 'var(--color-success)' },
    { label: '维修', value: faultCount, icon: <WarningOutlined />, color: 'var(--color-warning)' },
    { label: '特种设备数', value: specialCount, icon: <SafetyCertificateOutlined />, color: 'var(--color-error)' },
  ]

  const typeOptions = [...new Set(data.map(d => d.device_type).filter(Boolean))].map(t => ({ label: t, value: t }))

  // 获取列表
  useEffect(() => {
    let cancelled = false
    const run = async () => {
      setLoading(true)
      try {
        const params: Record<string, unknown> = { page: query.page, pageSize: query.pageSize, sortBy: 'device_type,device_code', sortOrder: 'asc' }
        if (query.keyword) params.keyword = query.keyword
        if (query.status && query.status.length > 0) params.status = query.status.join(',')
        if (query.device_type) params.device_type = query.device_type
        if (query.is_special !== undefined && query.is_special !== null) params.is_special = query.is_special
        const res = await api.get('/basic/devices', { params })
        if (cancelled) return
        const list = res.data || []
        setData(list)
        setTotal(res.total || list.length)
      } catch (err) {
        if (!cancelled) {
          message.error(err.message || '获取设备列表失败')
          setData([])
          setTotal(0)
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    run()
    return () => { cancelled = true }
  }, [query])

  const refresh = useCallback(() => setQuery(q => ({ ...q })), [])

  const handleSearch = () => {
    setQuery(q => ({ ...q, page: 1, keyword: keywordInput, status: statusInput, device_type: typeInput, is_special: specialInput }))
  }

  const handleReset = () => {
    setKeywordInput('')
    setStatusInput([1, 2, 0])
    setTypeInput(undefined)
    setSpecialInput(undefined)
    setQuery(q => ({ ...q, page: 1, keyword: '', status: [1, 2, 0], device_type: undefined, is_special: undefined }))
  }

  const handleDetail = (record) => {
    setCurrent(record)
    setDetailOpen(true)
  }

  const handleAdd = () => {
    setEditing(null)
    setModalVisible(true)
  }

  const handleEdit = (record) => {
    setEditing(record)
    setModalVisible(true)
  }

  // Modal 打开动画结束后再设置表单值（配合 destroyOnHidden + preserve={false}）
  const handleAfterOpenChange = (open) => {
    if (!open) return
    if (editing) {
      form.setFieldsValue({
        device_code: editing.device_code,
        device_name: editing.device_name,
        device_type: editing.device_type,
        device_model: editing.device_model,
        serial_no: editing.serial_no,
        location: editing.location,
        responsible_person: editing.responsible_person,
        is_special: editing.is_special === true || editing.is_special === 1 ? 1 : 0,
        status: editing.status,
        last_inspection_date: editing.last_inspection_date,
        inspection_cycle: editing.inspection_cycle,
        next_inspection_date: editing.next_inspection_date,
        manufacturer: editing.manufacturer,
        purchase_date: editing.purchase_date,
        warranty_end: editing.warranty_end,
      })
    } else {
      form.resetFields()
      form.setFieldsValue({ status: '正常', is_special: 0 })
    }
  }

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields()
      setSubmitting(true)
      const payload = { ...values }
      let res: any
      if (editing) {
        res = await api.put(`/basic/devices/${editing.device_id}`, payload)
      } else {
        res = await api.post('/basic/devices', payload)
      }
      if (res?.success === false) {
        message.error(res.message || '保存失败')
        return
      }
      message.success(res?.message || (editing ? '设备编辑成功' : '设备新增成功'))
      setModalVisible(false)
      refresh()
    } catch (e) {
      if (e?.errorFields) return
      message.error(e.message || '操作失败')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (record) => {
    try {
      const res = await api.delete(`/basic/devices/${record.device_id}`)
      if (res?.success === false) {
        message.error(res.message || '删除失败')
        return
      }
      message.success(res.message || '删除成功')
      refresh()
    } catch (err) {
      message.error(err.message || '删除失败')
    }
  }

  const columns = [
    { title: '设备编号', dataIndex: 'device_code', key: 'device_code', width: 130, fixed: 'left' as const },
    { title: '设备名称', dataIndex: 'device_name', key: 'device_name', width: 150 },
    { title: '型号', dataIndex: 'device_model', key: 'device_model', width: 130 },
    { title: '类型', dataIndex: 'device_type', key: 'device_type', width: 100 },
    { title: '位置', dataIndex: 'location', key: 'location', width: 140 },
    {
      title: '状态', dataIndex: 'status', key: 'status', width: 90,
      render: v => <Tag color={statusColorMap[v]}>{v}</Tag>,
    },
    {
      title: '特种设备', dataIndex: 'is_special', key: 'is_special', width: 100,
      render: v => (v === true || v === 1) ? <Tag color="orange">是</Tag> : <Tag>否</Tag>,
    },
    { title: '负责人', dataIndex: 'responsible_person', key: 'responsible_person', width: 100 },
    {
      title: '操作', key: 'action', width: 120, fixed: 'right' as const,
      render: (_, record) => (
        <Space size="small">
          <Button type="link" size="small" onClick={() => handleDetail(record)}>查看</Button>
          {hasPermission('pc:device:list:update') && (
            <Button type="link" size="small" onClick={() => handleEdit(record)}>编辑</Button>
          )}
          {hasPermission('pc:device:list:delete') && (
            <Button type="link" size="small" danger onClick={() => handleDelete(record)}>删除</Button>
          )}
        </Space>
      ),
    },
  ]

  const filters: FilterItem[] = [
    { type: 'input', placeholder: '搜索设备编号/名称/型号', col: { flex: '150px' }, value: keywordInput, onChange: (e) => setKeywordInput((e as React.ChangeEvent<HTMLInputElement>).target.value) },
    { type: 'select', placeholder: '设备类型', options: typeOptions, col: { flex: '150px' }, value: typeInput, onChange: (v) => setTypeInput(v as number | string | undefined) },
    {
      type: 'checkbox-group', placeholder: '状态筛选', col: { flex: '200px' },
      options: [{ label: '正常', value: 1 }, { label: '维修', value: 2 }, { label: '停用', value: 0 }],
      value: statusInput, onChange: (v) => setStatusInput(v as number[]),
    },
    { type: 'select', placeholder: '是否特种设备', options: specialOptions, col: { flex: '150px' }, value: specialInput, onChange: (v) => setSpecialInput(v as number | string | undefined) },
  ]

  return (
    <>
      <ThreeSectionPage
        title="设备档案"
        breadcrumbs="基础数据 / 设备档案"
        stats={stats}
        filters={filters}
        onSearch={handleSearch}
        onReset={handleReset}
        actions={
          <ActionButtons
            hasAdd={false}
            hasExport={false}
            extra={[
              hasPermission('pc:device:list:create') && (
                <Button key="add" type="primary" icon={<PlusOutlined />} onClick={handleAdd}>新增设备</Button>
              ),
            ]}
          />
        }
        table={
          <ResizableTable tableKey="pages_basic_DeviceManagement"             columns={columns}
            dataSource={data}
            rowKey="device_id"
            size="small"
            loading={loading}
            scroll={{ x: 1080 }}
            pagination={{
              current: query.page,
              pageSize: query.pageSize,
              total,
              showSizeChanger: true,
              showTotal: t => `共 ${t} 条`,
              onChange: (p, ps) => setQuery(q => ({ ...q, page: p, pageSize: ps })),
            }}
          />
        }
      />
      <Modal
        title={editing ? '编辑设备' : '新增设备'}
        open={modalVisible}
        onOk={handleSubmit}
        confirmLoading={submitting}
        onCancel={() => setModalVisible(false)}
        afterOpenChange={handleAfterOpenChange}
        okText="保存"
        cancelText="取消"
        width={680}
        destroyOnHidden
      >
        <Form form={form} layout="vertical" className="compact-form" preserve={false}>
          <Row gutter={12}>
            <Col span={12}>
              <Form.Item name="device_name" label="设备名称" rules={[{ required: true, message: '请输入设备名称' }]}>
                <Input placeholder="请输入设备名称" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="device_code" label="设备编号" rules={[{ required: true, message: '请输入设备编号' }]}>
                <Input placeholder="请输入设备编号" disabled={!!editing} />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={12}>
            <Col span={12}>
              <Form.Item name="device_type" label="设备类型" rules={[{ required: true, message: '请选择设备类型' }]}>
                <Select placeholder="请选择设备类型" options={[
                  { label: '生产设备', value: '生产设备' },
                  { label: '检测设备', value: '检测设备' },
                  { label: '辅助设备', value: '辅助设备' },
                  { label: '其他设备', value: '其他设备' },
                ]} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="device_model" label="设备型号">
                <Input placeholder="请输入设备型号" />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={12}>
            <Col span={12}>
              <Form.Item name="location" label="安装位置" rules={[{ required: true, message: '请输入位置' }]}>
                <Input placeholder="请输入位置" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="serial_no" label="出厂编号">
                <Input placeholder="请输入出厂编号" />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={12}>
            <Col span={8}>
              <Form.Item name="status" label="状态" rules={[{ required: true, message: '请选择状态' }]}>
                <Select placeholder="请选择状态" options={statusOptions} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="is_special" label="是否特种设备">
                <Select placeholder="请选择" options={specialOptions} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="responsible_person" label="负责人">
                <Input placeholder="请输入负责人" />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={12}>
            <Col span={8}>
              <Form.Item name="manufacturer" label="制造商">
                <Input placeholder="请输入制造商" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="purchase_date" label="购置日期">
                <Input placeholder="YYYY-MM-DD" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="warranty_end" label="保修截止">
                <Input placeholder="YYYY-MM-DD" />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={12}>
            <Col span={8}>
              <Form.Item name="last_inspection_date" label="上次检定日期">
                <Input placeholder="YYYY-MM-DD" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="inspection_cycle" label="检定周期（月）">
                <Input placeholder="如：6" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="next_inspection_date" label="下次检定日期">
                <Input placeholder="YYYY-MM-DD" />
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </Modal>
      <Drawer
        title="设备详情"
        open={detailOpen}
        onClose={() => setDetailOpen(false)}
        width={560}
      >
        {current && (
          <Descriptions column={1} bordered size="small">
            <Descriptions.Item label="设备编号">{current.device_code}</Descriptions.Item>
            <Descriptions.Item label="设备名称">{current.device_name}</Descriptions.Item>
            <Descriptions.Item label="设备型号">{current.device_model || '-'}</Descriptions.Item>
            <Descriptions.Item label="设备类型">{current.device_type || '-'}</Descriptions.Item>
            <Descriptions.Item label="出厂编号">{current.serial_no || '-'}</Descriptions.Item>
            <Descriptions.Item label="安装位置">{current.location || '-'}</Descriptions.Item>
            <Descriptions.Item label="状态"><Tag color={statusColorMap[current.status]}>{current.status}</Tag></Descriptions.Item>
            <Descriptions.Item label="是否特种设备">{(current.is_special === true || current.is_special === 1) ? <Tag color="orange">是</Tag> : <Tag>否</Tag>}</Descriptions.Item>
            <Descriptions.Item label="负责人">{current.responsible_person || '-'}</Descriptions.Item>
            <Descriptions.Item label="制造商">{current.manufacturer || '-'}</Descriptions.Item>
            <Descriptions.Item label="购置日期">{current.purchase_date || '-'}</Descriptions.Item>
            <Descriptions.Item label="保修截止">{current.warranty_end || '-'}</Descriptions.Item>
            <Descriptions.Item label="上次检定日期">{current.last_inspection_date || '-'}</Descriptions.Item>
            <Descriptions.Item label="检定周期（月）">{current.inspection_cycle || '-'}</Descriptions.Item>
            <Descriptions.Item label="下次检定日期">{current.next_inspection_date || '-'}</Descriptions.Item>
          </Descriptions>
        )}
      </Drawer>
    </>
  )
}
