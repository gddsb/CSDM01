import React, { useState, useEffect, useCallback, useMemo } from 'react'
import {
  Tag, Button, Select, DatePicker, Space, Input, Drawer, Form, Descriptions,
  Typography, message, Modal, Empty, Spin, Radio, Table, Checkbox, InputNumber, Upload, Image, Card,
} from 'antd'
import type { UploadFile } from 'antd/es/upload/interface'
import {
  ToolOutlined, ClockCircleOutlined, CheckCircleOutlined, SearchOutlined,
  ReloadOutlined, ThunderboltOutlined, DashboardOutlined,
  UploadOutlined,
} from '@ant-design/icons'
import ThreeSectionPage from '../../components/ThreeSectionPage'
import type { StatItem } from '../../components/ThreeSectionPage'
import dayjs from 'dayjs'
import api from '../../utils/api'
import { useApp } from '../../contexts/AppContext'

const { RangePicker } = DatePicker
const { TextArea } = Input
const { Title, Text } = Typography

// ===== 状态映射 =====
const STATUS_COLOR: Record<string, string> = {
  '待执行': 'default',
  '执行中': 'processing',
  '已完成': 'success',
  '跳过': 'warning',
}
const MODE_LABEL: Record<string, string> = {
  daily: '每日',
  weekly: '每周',
  monthly: '每月',
}
const MODE_COLOR: Record<string, string> = {
  daily: 'green',
  weekly: 'blue',
  monthly: 'purple',
}
const RESULT_COLOR: Record<string, string> = {
  '正常': 'success',
  '异常': 'error',
}

const STATUS_OPTIONS = [
  { label: '待执行', value: '待执行' },
  { label: '执行中', value: '执行中' },
  { label: '已完成', value: '已完成' },
  { label: '跳过', value: '跳过' },
]
const MODE_OPTIONS = [
  { label: '每日点检', value: 'daily' },
  { label: '每周保养', value: 'weekly' },
  { label: '每月保养', value: 'monthly' },
]
const JUDGE_OPTIONS = [
  { label: '定性（正常/异常）', value: '定性' },
  { label: '定量（数值范围）', value: '定量' },
]

/** 定量型：实测值 → 自动判定 正常/异常（区间/上下限/单点±10%） */
function autoJudge(actual: string, standard: string): '正常' | '异常' {
  const actualNum = parseFloat(actual)
  if (!actual || isNaN(actualNum)) return '正常'
  const std = standard || ''
  const range = std.match(/([\d.]+)\s*[~～\-—至到]\s*([\d.]+)/)
  if (range) { const lo = parseFloat(range[1]); const hi = parseFloat(range[2]); return (actualNum < lo || actualNum > hi) ? '异常' : '正常' }
  const ge = std.match(/[≥>=]\s*([\d.]+)/)
  if (ge) { const lo = parseFloat(ge[1]); return actualNum < lo ? '异常' : '正常' }
  const le = std.match(/[≤<=<]\s*([\d.]+)/)
  if (le) { const hi = parseFloat(le[1]); return actualNum > hi ? '异常' : '正常' }
  const single = std.match(/([\d.]+)/)
  if (single) { const target = parseFloat(single[1]); return (actualNum < target * 0.9 || actualNum > target * 1.1) ? '异常' : '正常' }
  return '正常'
}

export default function DeviceMaintenanceUnified() {
  const { hasPermission } = useApp()

  // ============ 执行记录列表 ============
  const [records, setRecords] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [total, setTotal] = useState(0)

  const [filters, setFilters] = useState({
    keyword: '',
    month: dayjs().format('YYYY-MM') as string | undefined,
  })

  // ============ 选中的设备（主表点击 → 子表显示） ============
  const [selectedDeviceId, setSelectedDeviceId] = useState<number | null>(null)

  // ============ 详情 Drawer ============
  const [detailOpen, setDetailOpen] = useState(false)
  const [detailData, setDetailData] = useState<any>(null)

  // ============ 完成保养 Modal ============
  const [completeOpen, setCompleteOpen] = useState(false)
  const [completeLoading, setCompleteLoading] = useState(false)
  const [completeRecord, setCompleteRecord] = useState<any>(null)
  const [form] = Form.useForm()
  const [resultType, setResultType] = useState<'正常' | '异常'>('正常')
  const [completeFileList, setCompleteFileList] = useState<UploadFile[]>([])

  // ============ 生成弹窗 ============
  const [genOpen, setGenOpen] = useState(false)
  const [genLoading, setGenLoading] = useState(false)
  const [genMonth, setGenMonth] = useState<string>(dayjs().format('YYYY-MM'))
  const [genSkipPast, setGenSkipPast] = useState<boolean>(true)
  const [genDeviceId, setGenDeviceId] = useState<number | undefined>(undefined)

  // ===== 按频率执行记录按设备分组 =====
  const loadRecords = useCallback(async () => {
    setLoading(true)
    try {
      const params: any = { page: 1, pageSize: 9999 }
      if (filters.keyword) params.keyword = filters.keyword
      if (filters.month) params.month = filters.month
      const res = await api.get('/basic/device-records', { params })
      const raw = res?.data
      const list = Array.isArray(raw) ? raw : (raw?.rows || raw?.list || [])
      setRecords(list)
      setTotal(res?.total || raw?.total || list.length)
    } catch (err: any) {
      message.error('加载维保计划失败')
    } finally {
      setLoading(false)
    }
  }, [filters])

  useEffect(() => { loadRecords() }, [loadRecords])

  // 筛选变化时清除选中，避免选中的设备被过滤掉
  useEffect(() => { setSelectedDeviceId(null) }, [filters])

  // ===== 按设备分组，含各频率完成度统计 =====
  const deviceGroups = useMemo(() => {
    const MODE_ORDER: Record<string, number> = { daily: 0, weekly: 1, monthly: 2 }
    const map = new Map<number, any>()
    records.forEach(r => {
      if (!map.has(r.device_id)) {
        map.set(r.device_id, {
          device_id: r.device_id,
          device_code: r.device_code,
          device_name: r.device_name,
          records: [],
        })
      }
      map.get(r.device_id)!.records.push(r)
    })
    return Array.from(map.values()).map(g => {
      // 子表排序：先按周期(period_key) → 同周期内按频率(日→周→月) → 保养项名称
      g.records.sort((a: any, b: any) => {
        const pk = (a.period_key || '').localeCompare(b.period_key || '')
        if (pk !== 0) return pk
        const ma = MODE_ORDER[a.trigger_mode] ?? 99
        const mb = MODE_ORDER[b.trigger_mode] ?? 99
        if (ma !== mb) return ma - mb
        const na = a.standard?.maintenance_content || ''
        const nb = b.standard?.maintenance_content || ''
        return na.localeCompare(nb, 'zh-CN')
      })
      const daily = g.records.filter((x: any) => x.trigger_mode === 'daily')
      const weekly = g.records.filter((x: any) => x.trigger_mode === 'weekly')
      const monthly = g.records.filter((x: any) => x.trigger_mode === 'monthly')
      const stat = (arr: any[]) => ({
        total: arr.length,
        completed: arr.filter((x: any) => x.status === '已完成').length,
      })
      return {
        ...g,
        dailyStat: stat(daily),
        weeklyStat: stat(weekly),
        monthlyStat: stat(monthly),
      }
    })
  }, [records])

  // ===== 生成维保计划 =====
  const handleGenerate = async () => {
    setGenLoading(true)
    try {
      const payload: any = { target_month: genMonth, skip_past: genSkipPast }
      if (genDeviceId) payload.device_id = genDeviceId
      const res = await api.post('/basic/device-records/generate', payload)
      message.success(res?.message || `完成：新增 ${res?.data?.created || 0} · 更新 ${res?.data?.updated || 0} · 清理 ${res?.data?.deleted || 0}`)
      setGenOpen(false)
      loadRecords()
    } catch (err: any) {
      message.error(err?.message || '生成失败')
    } finally {
      setGenLoading(false)
    }
  }

  // ===== 清理并重建维保计划（破坏性操作，含级联清理）=====
  const handleCleanupRegenerate = async () => {
    Modal.confirm({
      title: `确认清理并重建 ${genMonth} 维保计划？`,
      content: (
        <div>
          <p style={{ color: '#ff4d4f', marginBottom: 8 }}>⚠️ 此操作将：</p>
          <ul style={{ color: '#ff4d4f', paddingLeft: 20 }}>
            <li>删除 {genMonth} 所有维保执行记录（含已完成的历史）</li>
            <li>级联清理关联的保养图片和故障单</li>
            <li>按当前生效保养标准重新生成</li>
          </ul>
          <p style={{ color: '#999', fontSize: 12, marginTop: 8 }}>已执行中的记录也会被清理，请确认后再操作</p>
        </div>
      ),
      okText: '确认清理并重建',
      okButtonProps: { danger: true },
      cancelText: '取消',
      onOk: async () => {
        setGenLoading(true)
        try {
          const payload: any = { target_month: genMonth, skip_past: genSkipPast }
          if (genDeviceId) payload.device_id = genDeviceId
          const res = await api.post('/basic/device-records/cleanup-and-regenerate', payload)
          message.success(res?.message || '清理并重建完成')
          setGenOpen(false)
          loadRecords()
        } catch (err: any) {
          message.error(err?.message || '清理重建失败')
        } finally {
          setGenLoading(false)
        }
      },
    })
  }

  // ===== 开始执行 =====
  const handleStart = async (id: number) => {
    try {
      const res = await api.put(`/basic/device-records/${id}/start`, {})
      message.success(res?.message || '已开始执行')
      loadRecords()
    } catch (err: any) {
      message.error(err?.message || '操作失败')
    }
  }

  // ===== 打开完成保养弹窗 =====
  const openComplete = (record: any) => {
    setCompleteRecord(record)
    setResultType('正常')
    setCompleteFileList([])
    form.resetFields()
    form.setFieldsValue({ result: '正常' })
    setCompleteOpen(true)
  }

  // ===== 上传保养图片（返回全部成功才通过，否则抛错让上层处理） =====
  const uploadCompleteImages = async (recordId: number, files: File[]): Promise<number> => {
    if (files.length === 0) return 0
    const fd = new FormData()
    files.forEach(f => fd.append('images', f))
    const res = await api.post(`/basic/device-records/${recordId}/images`, fd)

    // 后端 uploadImage 返回 success(res, savedArray, msg)
    // 结构：{ success: true, message: "成功上传 N 张", data: [imgObj1, imgObj2, ...] }
    // data 是数组（已保存的图片对象），不是 { saved, failed, total } 对象
    const data = res?.data
    let savedCount: number
    if (Array.isArray(data)) {
      // 数组模式：data.length = 实际成功保存的图片数
      savedCount = data.length
    } else if (data && typeof data === 'object' && 'saved' in data) {
      // 对象模式：兼容可能的扩展返回
      savedCount = (data as any).saved ?? 0
    } else {
      savedCount = 0
    }

    // 真正失败的判断：业务层明确返回 success: false
    if (res?.success === false) {
      throw new Error(res?.message || '图片上传失败')
    }
    // 没有保存任何图片
    if (savedCount === 0) {
      throw new Error(res?.message || '所有图片上传失败')
    }
    // 部分失败（上传的数量少于提交的）
    if (savedCount < files.length) {
      throw new Error(res?.message || `${savedCount}/${files.length} 张图片上传成功`)
    }
    return savedCount
  }

  // ===== 完成保养（先上传图片，全部成功后再提交执行结果） =====
  const handleComplete = async () => {
    const values = await form.validateFields()
    // 定量型：用自动判定覆盖用户手动 result
    if (completeRecord?.standard?.judge_type === '定量') {
      values.result = autoJudge(values.actual_value || '', completeRecord?.standard?.standard_value || '')
    }
    // 收集待上传的本地文件
    const pendingFiles = completeFileList
      .filter(f => f.originFileObj)
      .map(f => f.originFileObj as File)

    setCompleteLoading(true)
    try {
      // Step 1: 先上传图片，任何失败都不会提交完成（回滚）
      if (pendingFiles.length > 0) {
        await uploadCompleteImages(completeRecord.record_id, pendingFiles)
      }

      // Step 2: 图片全部成功（或无图片），再提交完成
      const res = await api.put(`/basic/device-records/${completeRecord.record_id}/submit`, values)
      if (res?.success !== false) {
        message.success(res?.message || '完成保养成功')
        setCompleteOpen(false)
        loadRecords()
      } else {
        message.error(res?.message || '提交失败')
      }
    } catch (err: any) {
      // 图片上传或提交失败均提示用户，Modal 保持打开可重试
      const msg = err?.message || '未知错误'
      if (msg.includes('图片') || msg.includes('上传')) {
        message.error(`图片上传失败：${msg}。保养结果尚未提交，请检查网络后重试`)
      } else {
        message.error(`提交失败：${msg}`)
      }
    } finally {
      setCompleteLoading(false)
    }
  }

  // ===== 详情 =====
  const handleDetail = async (id: number) => {
    try {
      const res = await api.get(`/basic/device-records/${id}`)
      setDetailData(res?.data || res)
      setDetailOpen(true)
    } catch {
      message.error('加载详情失败')
    }
  }

  // ===== 删除 =====
  const handleDelete = async (id: number) => {
    try {
      await api.delete(`/basic/device-records/${id}`)
      message.success('删除成功')
      loadRecords()
    } catch (err: any) {
      message.error(err?.message || '删除失败')
    }
  }

  // ===== 统计 =====
  const statItems: StatItem[] = [
    { label: '待执行', value: records.filter(r => r.status === '待执行').length, color: 'var(--color-warning)', icon: <ClockCircleOutlined /> },
    { label: '执行中', value: records.filter(r => r.status === '执行中').length, color: 'var(--color-primary)', icon: <ToolOutlined /> },
    { label: '已完成', value: records.filter(r => r.status === '已完成').length, color: 'var(--color-success)', icon: <CheckCircleOutlined /> },
    { label: '异常项', value: records.filter(r => r.result === '异常').length, color: 'var(--color-error)', icon: <ThunderboltOutlined /> },
    { label: '总记录数', value: total, color: '#722ed1', icon: <DashboardOutlined /> },
  ]

  // ===== 子表列定义（调整列宽到刚好显示内容）=====
  const recordColumns = [
    { title: '记录编号', dataIndex: 'record_no', width: 150 },
    {
      title: '保养项', width: 180, render: (_: any, r: any) => (
        <div>
          <div style={{ fontWeight: 500 }}>{r.standard?.maintenance_content || '-'}</div>
          {r.standard?.mechanism && <Text type="secondary" style={{ fontSize: 12 }}>{r.standard.mechanism}</Text>}
        </div>
      ),
    },
    {
      title: '频率', width: 80, render: (_: any, r: any) => (
        <Tag color={MODE_COLOR[r.trigger_mode]}>{MODE_LABEL[r.trigger_mode] || r.trigger_mode}</Tag>
      ),
    },
    {
      title: '周期', dataIndex: 'period_key', width: 100, render: (v: string) => v || <Text type="secondary">-</Text>,
    },
    {
      title: '状态', width: 80, render: (_: any, r: any) => (
        <Tag color={STATUS_COLOR[r.status]}>{r.status}</Tag>
      ),
    },
    {
      title: '结果', width: 80, render: (_: any, r: any) => r.result
        ? <Tag color={RESULT_COLOR[r.result]}>{r.result}</Tag>
        : <Text type="secondary">-</Text>,
    },
    { title: '执行人', dataIndex: 'executor_name', width: 90, render: (v: string) => v || '-' },
    {
      title: '执行日期', width: 120, render: (_: any, r: any) => {
        const d = r.end_time || r.start_time
        return d ? dayjs(d).format('YYYY-MM-DD') : <Text type="secondary">-</Text>
      },
    },
    {
      title: '操作', width: 150, fixed: 'right' as const, render: (_: any, r: any) => (
        <Space size={4}>
          <Button size="small" type="link" onClick={() => handleDetail(r.record_id)}>详情</Button>
          {r.status === '待执行' && hasPermission('pc:device:maintenance:start') && (
            <Button size="small" type="link" onClick={() => handleStart(r.record_id)}>开始</Button>
          )}
          {r.status === '执行中' && hasPermission('pc:device:maintenance:submit') && (
            <Button size="small" type="link" onClick={() => openComplete(r)}>完成</Button>
          )}
        </Space>
      ),
    },
  ]

  // ===== 外层设备分组列定义（按频率显示完成度，如 3/5）=====
  const renderModeStat = (stat: { completed: number; total: number }) => {
    const color = stat.completed === stat.total && stat.total > 0 ? 'var(--color-success)' : 'var(--color-primary)'
    return (
      <div style={{ fontSize: 15, fontWeight: 600, color, textAlign: 'center' }}>
        {stat.completed}<span style={{ color: '#bbb', fontSize: 12 }}> / </span>{stat.total}
      </div>
    )
  }
  const deviceColumns = [
    { title: '设备编号', dataIndex: 'device_code', width: 150, fixed: 'left' as const },
    { title: '设备名称', dataIndex: 'device_name', width: 220, fixed: 'left' as const },
    {
      title: '日点检', width: 90, align: 'center' as const,
      render: (_: any, r: any) => renderModeStat(r.dailyStat),
    },
    {
      title: '周保养', width: 90, align: 'center' as const,
      render: (_: any, r: any) => renderModeStat(r.weeklyStat),
    },
    {
      title: '月保养', width: 90, align: 'center' as const,
      render: (_: any, r: any) => renderModeStat(r.monthlyStat),
    },
  ]

  const selectedDevice = deviceGroups.find((g: any) => g.device_id === selectedDeviceId)

  return (
    <>
    <ThreeSectionPage
      title="设备保养（点检+维护）"
      breadcrumbs="设备管理 / 设备保养"
      stats={statItems}
      filter={
        <Space wrap>
          <Input
            placeholder="编号/设备名/记录号搜索" allowClear prefix={<SearchOutlined />}
            style={{ width: 260 }}
            value={filters.keyword}
            onChange={(e) => setFilters(f => ({ ...f, keyword: e.target.value }))}
          />
          <DatePicker
            picker="month"
            placeholder="选择月份"
            style={{ width: 160 }}
            value={filters.month ? dayjs(filters.month) : undefined}
            onChange={(d) => setFilters(f => ({ ...f, month: d?.format('YYYY-MM') || undefined }))}
            format="YYYY年MM月"
            allowClear
          />
        </Space>
      }
      actions={
        <Space>
          {hasPermission('pc:device:maintenance:generate') && (
            <Button type="primary" icon={<ThunderboltOutlined />} onClick={() => {
              setGenMonth(dayjs().format('YYYY-MM'))
              setGenSkipPast(true)
              setGenDeviceId(selectedDeviceId ?? undefined)
              setGenOpen(true)
            }}>生成维保计划</Button>
          )}
          <Button icon={<ReloadOutlined />} onClick={loadRecords}>刷新</Button>
        </Space>
      }
      table={
        <>
          {/* === 上部：主表（设备列表，固定5行可滚动）=== */}
          <Spin spinning={loading}>
            <Table
              rowKey="device_id"
              columns={deviceColumns}
              dataSource={deviceGroups}
              scroll={{ x: 620, y: 235 }}
              pagination={false}
              size="small"
              onRow={(r) => ({
                onClick: () => setSelectedDeviceId(r.device_id),
              })}
              rowClassName={(r) => r.device_id === selectedDeviceId ? 'device-row-selected' : ''}
              locale={{ emptyText: <Empty description="暂无维保计划" /> }}
            />
          </Spin>

          {/* === 下部：子表（选中设备的执行记录）=== */}
          <div style={{ marginTop: 16 }}>
            {selectedDevice ? (
              <Table
                rowKey="record_id"
                columns={recordColumns}
                dataSource={selectedDevice.records}
                pagination={false}
                size="small"
                scroll={{ x: 1030, y: 320 }}
              />
            ) : (
              <div style={{ padding: '40px 0', textAlign: 'center', color: '#bbb', background: 'var(--bg-card)', border: '1px dashed #e8e8e8', borderRadius: 6 }}>
                👆 请在上方设备列表中点击选择一台设备，查看其维保计划
              </div>
            )}
          </div>

          <style>{`
            .device-row-selected { background: #e6f4ff !important; }
            .device-row-selected td { background: #e6f4ff !important; }
          `}</style>
        </>
      }
    />

    {/* ===== 生成维保计划弹窗 ===== */}
      <Modal
        title="生成维保计划"
        open={genOpen}
        onCancel={() => setGenOpen(false)}
        footer={[
          <Button key="cancel" onClick={() => setGenOpen(false)}>取消</Button>,
          hasPermission('pc:device:maintenance:cleanup') && (
            <Button
              key="cleanup"
              danger
              icon={<ReloadOutlined />}
              loading={genLoading}
              onClick={handleCleanupRegenerate}
              style={{ marginLeft: 'auto' }}
            >
              清理并重建
            </Button>
          ),
          hasPermission('pc:device:maintenance:generate') && (
            <Button key="ok" type="primary" icon={<ThunderboltOutlined />} loading={genLoading} onClick={handleGenerate}>
              正常生成
            </Button>
          ),
        ]}
      >
        <div style={{ marginBottom: 12 }}>
          <Text>生成月份：</Text>
          <DatePicker
            picker="month"
            value={dayjs(genMonth)}
            onChange={(d) => setGenMonth(d?.format('YYYY-MM') || dayjs().format('YYYY-MM'))}
            format="YYYY-MM"
          />
          {genMonth === dayjs().format('YYYY-MM') && (
            <Checkbox checked={genSkipPast} onChange={(e) => setGenSkipPast(e.target.checked)} style={{ marginLeft: 12 }}>
              本月跳过已过去的日期
            </Checkbox>
          )}
        </div>
        <div>
          <Text>限定设备（可选，不选则为全部设备）：</Text>
          <Select
            placeholder="全部设备" allowClear
            style={{ width: 280 }}
            value={genDeviceId}
            onChange={setGenDeviceId}
            options={[{ label: '全部设备', value: undefined, disabled: true }, ...deviceGroups.map((g: any) => ({
              label: `${g.device_code || ''} ${g.device_name || ''}`.trim(),
              value: g.device_id,
            }))]}
          />
        </div>
      </Modal>

      {/* ===== 详情 Drawer ===== */}
      <Drawer
        title={`维保记录详情 ${detailData?.record_no || ''}`}
        open={detailOpen}
        width={640}
        onClose={() => setDetailOpen(false)}
      >
        {detailData && (
          <>
            <Descriptions column={1} bordered size="small">
              <Descriptions.Item label="记录编号">{detailData.record_no}</Descriptions.Item>
              <Descriptions.Item label="设备">{detailData.device_name} ({detailData.device_code})</Descriptions.Item>
              <Descriptions.Item label="保养项">{detailData.standard?.maintenance_content || '-'}</Descriptions.Item>
              {detailData.standard?.mechanism && <Descriptions.Item label="机构">{detailData.standard.mechanism}</Descriptions.Item>}
              {detailData.standard?.component && <Descriptions.Item label="部件">{detailData.standard.component}</Descriptions.Item>}
              {detailData.standard?.location && <Descriptions.Item label="部位">{detailData.standard.location}</Descriptions.Item>}
              {detailData.standard?.standard_value && <Descriptions.Item label="判定基准">{detailData.standard.standard_value}</Descriptions.Item>}
              {detailData.standard?.maintenance_method && <Descriptions.Item label="保养方法">{detailData.standard.maintenance_method}</Descriptions.Item>}
              <Descriptions.Item label="频率">
                <Tag color={MODE_COLOR[detailData.trigger_mode]}>{MODE_LABEL[detailData.trigger_mode]}</Tag>
              </Descriptions.Item>
              {detailData.period_key && <Descriptions.Item label="周期">{detailData.period_key}</Descriptions.Item>}
              <Descriptions.Item label="状态">
                <Tag color={STATUS_COLOR[detailData.status]}>{detailData.status}</Tag>
              </Descriptions.Item>
              {detailData.result && (
                <Descriptions.Item label="结果">
                  <Tag color={RESULT_COLOR[detailData.result]}>{detailData.result}</Tag>
                </Descriptions.Item>
              )}
              {detailData.actual_value && <Descriptions.Item label="实测值">{detailData.actual_value}</Descriptions.Item>}
              {detailData.abnormal_desc && <Descriptions.Item label="异常描述">{detailData.abnormal_desc}</Descriptions.Item>}
              {detailData.executor_name && <Descriptions.Item label="执行人">{detailData.executor_name}</Descriptions.Item>}
              {detailData.start_time && <Descriptions.Item label="开始时间">{dayjs(detailData.start_time).format('YYYY-MM-DD HH:mm')}</Descriptions.Item>}
              {detailData.end_time && <Descriptions.Item label="结束时间">{dayjs(detailData.end_time).format('YYYY-MM-DD HH:mm')}</Descriptions.Item>}
              {detailData.duration_min && <Descriptions.Item label="耗时">{detailData.duration_min} 分钟</Descriptions.Item>}
              {detailData.remarks && <Descriptions.Item label="备注">{detailData.remarks}</Descriptions.Item>}
            </Descriptions>

            {detailData.maintenance_images?.length > 0 && (
              <Card
                size="small"
                title="保养图片"
                style={{ marginTop: 12 }}
                bodyStyle={{ padding: 12 }}
              >
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                  {detailData.maintenance_images.map((img: any) => (
                    <Image
                      key={img.image_id}
                      width={100}
                      height={100}
                      style={{ objectFit: 'cover', borderRadius: 4, border: '1px solid #eee' }}
                      src={img.file_path}
                      alt="保养图片"
                    />
                  ))}
                </div>
              </Card>
            )}
          </>
        )}
      </Drawer>

      {/* ===== 完成保养 Modal ===== */}
      <Modal
        title={
          <span>
            <CheckCircleOutlined style={{ color: 'var(--color-success)', marginRight: 8 }} />
            完成保养执行 — {completeRecord?.record_no || ''}
          </span>
        }
        open={completeOpen}
        confirmLoading={completeLoading}
        onOk={handleComplete}
        onCancel={() => setCompleteOpen(false)}
        okText="提交完成"
        cancelText="取消"
        width={560}
        destroyOnClose
      >
        {completeRecord && (
          <div style={{ marginBottom: 12, padding: 12, background: 'var(--bg-card)', borderRadius: 6, fontSize: 13 }}>
            <div><Text type="secondary">设备：</Text>{completeRecord.device_name} ({completeRecord.device_code})</div>
            <div><Text type="secondary">保养项：</Text>{completeRecord.standard?.maintenance_content || '-'}</div>
            <div><Text type="secondary">周期：</Text>{completeRecord.period_key} <Tag color={MODE_COLOR[completeRecord.trigger_mode]} style={{ marginLeft: 4 }}>{MODE_LABEL[completeRecord.trigger_mode]}</Tag></div>
          </div>
        )}
        <Form form={form} layout="vertical">
          {/* 定量型：执行结果由系统自动判定（只读） */}
          {completeRecord?.standard?.judge_type === '定量' ? (
            <Form.Item name="result" label="执行结果">
              <span style={{ color: 'var(--color-text-secondary)', fontSize: 13 }}>
                系统根据实测值自动判定（提交时计算）
              </span>
            </Form.Item>
          ) : (
            <Form.Item name="result" label="执行结果" rules={[{ required: true, message: '请选择执行结果' }]}>
              <Radio.Group onChange={(e) => setResultType(e.target.value)}>
                <Radio value="正常"><Tag color="success">正常</Tag>（保养完成，无异常）</Radio>
                <Radio value="异常"><Tag color="error">异常</Tag>（发现问题，需创建故障）</Radio>
              </Radio.Group>
            </Form.Item>
          )}

          <Form.Item shouldUpdate={(prev, cur) => prev.result !== cur.result || prev.actual_value !== cur.actual_value} noStyle>
            {({ getFieldValue }) => {
              const isAbnormal = getFieldValue('result') === '异常'
              const isQuant = completeRecord?.standard?.judge_type === '定量'
              return (
                <>
                  {/* 定量型才显示实测值 */}
                  {isQuant && (
                    <Form.Item name="actual_value" label={`实测值（标准：${completeRecord?.standard?.standard_value || '—'}${completeRecord?.standard?.unit || ''}）`}>
                      <Input placeholder="请输入实测数值" onChange={(e) => {
                        const r = autoJudge(e.target.value, completeRecord?.standard?.standard_value || '')
                        form.setFieldValue('result', r)
                      }} />
                    </Form.Item>
                  )}

                  {isAbnormal && (
                    <Form.Item name="abnormal_desc" label="异常描述" rules={[{ required: true, message: '请填写异常描述' }]}>
                      <TextArea rows={3} placeholder="描述发现的异常情况、位置、严重程度等" />
                    </Form.Item>
                  )}

                  <Form.Item name="duration_min" label="耗时（分钟）">
                    <InputNumber min={0} style={{ width: 160 }} placeholder="自动计算" />
                  </Form.Item>

                  <Form.Item name="remarks" label="备注">
                    <TextArea rows={2} placeholder="其他需要说明的事项" />
                  </Form.Item>

                  <Form.Item label="保养图片（最多10张）">
                    <Upload
                      listType="picture-card"
                      multiple
                      accept="image/*"
                      fileList={completeFileList}
                      beforeUpload={() => false}
                      onChange={({ fileList }) => setCompleteFileList(fileList)}
                      maxCount={10}
                    >
                      <div>
                        <UploadOutlined />
                        <div style={{ marginTop: 4 }}>上传图片</div>
                      </div>
                    </Upload>
                  </Form.Item>
                </>
              )
            }}
          </Form.Item>
        </Form>
      </Modal>
    </>
  )
}
