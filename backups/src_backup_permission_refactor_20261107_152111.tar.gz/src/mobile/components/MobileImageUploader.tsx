/**
 * 通用移动端图片上传组件
 *
 * 核心设计：绕开 antd-mobile ImageUploader 的 upload 状态机，
 * 自绘 "+" cell + ActionSheet 二选一 + 两个隐藏 <input type="file"> 精确控制相机/相册。
 *
 * 为什么不传 upload prop 给 antd-mobile：
 *   - 传了就会渲染内置 "+" + 内部隐藏 input，无法精确区分相机/相册
 *   - 还会渲染 uploading cell + 等 Promise resolve，hack 永不 resolve 会永远转圈
 *   - disableUpload 彻底干掉这些副作用，我们完全接管上传链路
 *
 * 功能：
 *   - ActionSheet 二选一：📷 相机拍摄（capture="environment" 直接开后置相机）/ 🖼️ 相册选择
 *   - 图片压缩（compressImage）+ 水印（可选 username + timestamp）
 *   - 上传：默认 api.post(uploadUrl, FormData)，返回值兼容 {url}/{urls}/string[] 三种形态
 *   - 删除：乐观更新 + 默认 api.delete(deleteUrl)，可自定义
 *   - 上传日志钩子（可选 onLog），外部可接 log-queue 等
 *
 * 用法示例：
 *   <MobileImageUploader
 *     uploadUrl={(f) => `/production/report-images/${reportNo}/${category}/upload`}
 *     deleteUrl={(u) => `/production/report-images/by-url?url=${encodeURIComponent(u)}`}
 *     value={defect_images} onChange={setDefectImages} maxCount={9}
 *     watermark={{ username: '张三', timestamp: true }}
 *     onLog={(lv, st, ctx) => pushLog({ stage, ctx, level: lv })}
 *   />
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import { ActionSheet, Image, ImageViewer, Toast, DotLoading } from 'antd-mobile'
import type { ImageUploadItem } from 'antd-mobile/es/components/image-uploader'
import api from '../../utils/api'
import { resolveUploadUrl } from '../../utils/resolveUploadUrl'
import { compressImage } from '../utils/image-compress'

type LogLevel = 'info' | 'warn' | 'error'

/** 受控图片值：纯路径字符串，或带 image_id 的对象（支持按 ID 删除） */
export interface UploadImageValue {
  url: string
  imageId?: number
}

interface Props {
  /** 上传接口 URL —— 可传固定 string 或按文件动态生成 */
  uploadUrl?: string | ((file: File) => string)
  /** 上传时附加的文本字段（如 { image_type: 'repair' }） */
  uploadData?: Record<string, string>
  /** 删除接口 URL —— 传相对路径 rawUrl + imageId，返回完整 DELETE URL；返回空串则不发起请求。不传则禁用删图功能 */
  deleteUrl?: string | ((rawUrl: string, imageId?: number) => string)
  /** 受控：后端返回的相对路径数组，或带 imageId 的对象数组 */
  value: Array<string | UploadImageValue>
  /** 受控回调：urls 为路径数组，items 含 imageId（父组件需持久化 ID 时使用第二个参数） */
  onChange: (urls: string[], items: UploadImageValue[]) => void
  /** 最大数量，默认 9 */
  maxCount?: number
  /** 标签（可选） */
  label?: string
  /** 是否压缩，默认 true */
  compress?: boolean
  /** 水印（可选） */
  watermark?: { username?: string; timestamp?: boolean } | null
  /** 上传超时 ms，默认 60000 */
  timeout?: number
  /** 上传日志钩子（可选，不传则静默） */
  onLog?: (level: LogLevel, stage: string, ctx: any) => void
  /** 上传模式：immediate（默认，选完立即 POST 到 uploadUrl）/ blob（压缩+水印后返回 blob URL，外部自己处理上传时机） */
  uploadMode?: 'immediate' | 'blob'
  /** blob 模式专用：每次选完图（压缩+水印后）emit 出 File[]，外部 submit 时拼 multipart 用 */
  onFilesReady?: (files: File[]) => void
  /** 只读模式：隐藏 "+" 上传按钮 + 隐藏删除选项，点击缩略图仍可全屏预览 */
  readOnly?: boolean
}

/** 重置隐藏 input 的 value —— 让用户选同一个文件也能再次触发 onChange */
function resetInput(input: HTMLInputElement | null) {
  if (input) input.value = ''
}

/** 后端相对路径 / {url,imageId} ↔ ImageUploadItem[] */
function toItems(urls: Array<string | UploadImageValue> | undefined | null): ImageUploadItem[] {
  if (!urls || urls.length === 0) return []
  return urls
    .map((u) => {
      const raw = typeof u === 'string' ? u : (u?.url || '')
      if (!raw) return null
      const imageId = typeof u === 'string' ? undefined : u?.imageId
      const item: any = { url: resolveUploadUrl(raw), key: raw }
      if (imageId) item.imageId = imageId
      return item as ImageUploadItem
    })
    .filter(Boolean) as ImageUploadItem[]
}

/** 内部 items → 受控值（保留 imageId，供父组件按 ID 删除） */
function toValueItems(items: ImageUploadItem[]): UploadImageValue[] {
  return items
    .filter((i: any) => !i.uploading && typeof i.key === 'string' && i.key)
    .map((i: any) => (i.imageId ? { url: i.key, imageId: i.imageId } : { url: i.key }))
}
function toUrls(items: ImageUploadItem[]): string[] {
  return items
    .map((i) => (typeof i.key === 'string' && i.key) ? i.key : (typeof i.url === 'string' ? i.url : ''))
    .filter(Boolean)
}
function getRawUrl(item: ImageUploadItem): string {
  if (typeof item.key === 'string' && item.key) return item.key
  return typeof item.url === 'string' ? item.url : ''
}

/** 从 api.post 返回值里提取 rawUrl —— 兼容后端多种返回形态 */
function extractRawUrl(resData: any): string {
  const d = resData
  if (!d) return ''
  if (typeof d === 'string') return d
  // 对象数组（如维保 saved: [{file_path,...}]）
  if (Array.isArray(d)) {
    const first: any = d[0]
    if (!first) return ''
    if (typeof first === 'string') return first
    return first.file_path || first.path || first.url || first.src || ''
  }
  if (typeof d.url === 'string') return d.url
  if (Array.isArray(d.urls)) return extractRawUrl(d.urls)
  // 单个对象（如 {file_path: '/uploads/...'}）
  if (typeof d.file_path === 'string') return d.file_path
  if (typeof d.path === 'string') return d.path
  return ''
}

/** 从上传返回值里提取 image_id（后端各接口均返回完整记录） */
function extractImageId(resData: any): number | undefined {
  const d = resData
  if (!d) return undefined
  const obj = Array.isArray(d) ? d[0] : d
  if (!obj || typeof obj !== 'object') return undefined
  const id = obj.image_id ?? obj.imageId ?? obj.id
  const n = Number(id)
  return Number.isFinite(n) && n > 0 ? n : undefined
}

export function MobileImageUploader({
  uploadUrl, deleteUrl, value, onChange, uploadData,
  maxCount = 9, label,
  compress = true, watermark = null,
  timeout = 60000, onLog,
  uploadMode = 'immediate',
  onFilesReady,
  readOnly = false,
}: Props) {
  const [items, setItems] = useState<ImageUploadItem[]>(() => toItems(value))

  // 外部 value 变化时同步（父组件保存后或初始加载）
  useEffect(() => { setItems(toItems(value)) }, [JSON.stringify(value)])

  // 两个隐藏 <input type="file"> —— 精确控制入口
  // cameraInput: capture="environment" → 直接开后置相机，拍完就返回
  // galleryInput: multiple → 只跳相册，支持多选
  const cameraInputRef = useRef<HTMLInputElement>(null)
  const galleryInputRef = useRef<HTMLInputElement>(null)

  const remaining = maxCount - items.length

  const emitLog = useCallback((level: LogLevel, stage: string, ctx: any) => {
    const tag = `[IMG-UPLOAD] [${stage}]`
    if (level === 'info') console.log(tag, ctx)
    else if (level === 'warn') console.warn(tag, ctx)
    else console.error(tag, ctx)
    onLog?.(level, stage, ctx)
  }, [onLog])

  // ========== "+" 点击 → ActionSheet 二选一 ==========
  const handleAddClick = useCallback(() => {
    if (remaining <= 0) {
      Toast.show({ content: `已达上限（${maxCount} 张）`, position: 'bottom' })
      return
    }
    ActionSheet.show({
      actions: [
        { text: '📷 相机拍摄', key: 'camera' },
        { text: '🖼️ 相册选择', key: 'gallery' },
      ],
      cancelText: '取消',
      closeOnAction: true,
      onAction: (action) => {
        emitLog('info', 'ACTION', { target: action.key, remaining })
        if (action.key === 'camera') cameraInputRef.current?.click()
        else if (action.key === 'gallery') galleryInputRef.current?.click()
      },
    })
  }, [remaining, maxCount, emitLog])

  // ========== 上传核心 —— 单文件 ==========
  const upload = useCallback(async (file: File): Promise<ImageUploadItem> => {
    const stageStart = performance.now()

    if (!file || !(file instanceof File)) {
      Toast.show({ content: '图片文件异常，请重试', position: 'bottom' })
      throw new Error('invalid file')
    }

    // 压缩 + 水印（watermark=null 时跳过水印）
    if (compress) {
      try {
        file = await compressImage(file, watermark ? {
          watermark: {
            timestamp: watermark.timestamp ? Date.now() : undefined,
            username: watermark.username || undefined,
          },
        } : undefined)
      } catch (err: any) {
        emitLog('warn', 'COMPRESS_SKIP', { reason: err?.message })
      }
    }

    // blob 模式：压缩+水印后不上传，返回 blob URL 给 UI，File 对象通过 onFilesReady 给外部
    if (uploadMode === 'blob') {
      const blobUrl = URL.createObjectURL(file)
      emitLog('info', 'BLOB_READY', { bytes: file.size })
      return { url: blobUrl, key: blobUrl, file } as any
    }

    const fd = new FormData()
    fd.append('files', file)
    if (uploadData) {
      Object.entries(uploadData).forEach(([k, v]) => fd.append(k, v))
    }
    const url = typeof uploadUrl === 'function' ? uploadUrl(file) : uploadUrl
    emitLog('info', 'REQUEST', { method: 'POST', url, bytes: file.size })

    try {
      const res: any = await api.post(url, fd, { timeout })
      if (!res?.success) {
        Toast.show({ content: res?.message || '上传失败', icon: 'fail', position: 'bottom' })
        throw new Error(res?.message || '上传失败')
      }

      const rawUrl = extractRawUrl(res.data)
      if (!rawUrl) {
        Toast.show({ content: '服务器未返回图片地址', icon: 'fail', position: 'bottom' })
        throw new Error('no url returned')
      }

      emitLog('info', 'UPLOAD_OK', { rawUrl, ms: Math.round(performance.now() - stageStart) })
      // key 存后端相对路径；imageId 用于按主键删除
      const imageId = extractImageId(res.data)
      const item: any = { url: resolveUploadUrl(rawUrl), key: rawUrl }
      if (imageId) item.imageId = imageId
      return item
    } catch (e: any) {
      const isTimeout = e?.code === 'ECONNABORTED' || /timeout/i.test(String(e?.message))
      Toast.show({
        content: isTimeout ? '上传超时，请检查网络后重试' : (e?.message || '图片上传失败'),
        icon: 'fail', position: 'bottom',
      })
      throw e
    }
  }, [uploadUrl, uploadData, compress, watermark, timeout, emitLog])

  // ========== 文件处理入口 —— 串行上传剩余名额内的文件 ==========
  const handleFiles = useCallback(async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return
    const files = Array.from(fileList).slice(0, remaining)
    if (files.length === 0) {
      Toast.show({ content: `最多 ${maxCount} 张`, position: 'bottom' })
      return
    }
    emitLog('info', 'HANDLE_FILES', { count: files.length, remaining })
    for (const file of files) {
      try {
        // 先塞占位 → UI 立即显示 80x80 "上传中..." 遮罩
        const blobUrl = URL.createObjectURL(file)
        const placeholder: any = { url: blobUrl, key: '', uploading: true, _tmp: blobUrl }
        setItems(prev => [...prev, placeholder])

        const result: any = await upload(file)

        setItems(prev => {
          const next = prev.map((i: any) =>
            i._tmp === blobUrl ? { ...result, _tmp: blobUrl } : i
          )
          onChange(toUrls(next), toValueItems(next))
          if (uploadMode === 'blob' && onFilesReady) {
            const files2 = next.map((i: any) => i.file).filter((f: any) => f instanceof File) as File[]
            if (files2.length > 0) onFilesReady(files2)
          }
          emitLog('info', 'UI_CHANGE', { prev: prev.length, next: next.length })
          return next
        })
        setTimeout(() => URL.revokeObjectURL(blobUrl), 3000)
      } catch {
        // upload 内部已 Toast，移除占位
        setItems(prev => prev.filter((i: any) => !i.uploading))
      }
    }
  }, [upload, remaining, maxCount, onChange, emitLog])

  // ========== 删除单张：乐观更新 UI + 后端双删 ==========
  const handleDelete = useCallback(async (rawUrl: string, imageId?: number) => {
    const removedItem = items.find(i => getRawUrl(i) === rawUrl)
    if (!removedItem) return

    const newItems = items.filter(i => getRawUrl(i) !== rawUrl)
    setItems(newItems)
    onChange(toUrls(newItems), toValueItems(newItems))
    emitLog('info', 'UI_DELETE', { removed: rawUrl, imageId, remaining: newItems.length })

    if (!deleteUrl) return  // 纯 blob 模式不传 deleteUrl 时跳过

    try {
      const delPath = typeof deleteUrl === 'function' ? deleteUrl(rawUrl, imageId) : deleteUrl
      if (!delPath) return  // 回调返回空串 → 无可用删除地址，仅本地移除
      emitLog('info', 'DELETE_REQUEST', { url: delPath })
      await api.delete(delPath)
    } catch (e: any) {
      emitLog('error', 'DELETE_FAIL', { msg: e?.message })
      Toast.show({ content: '图片已从列表移除，但后端删除失败', icon: 'fail', position: 'bottom' })
    }
  }, [items, onChange, deleteUrl, emitLog])

  // ========== 缩略图点击：直接预览（删除走右上角 ✕ 角标） ==========
  const handleThumbClick = useCallback((item: ImageUploadItem) => {
    const rawUrl = getRawUrl(item)
    const validItems = items.filter((i: any) => !(i as any).uploading)
    const urls = validItems
      .map((i) => (typeof i.url === 'string' ? i.url : getRawUrl(i)))
      .filter(Boolean)
    if (urls.length === 0) return
    const curIdx = validItems.findIndex((i) => getRawUrl(i) === rawUrl)
    ImageViewer.Multi.show({ images: urls, defaultIndex: curIdx >= 0 ? curIdx : 0 })
  }, [items])

  return (
    <div>
      {label && (
        <div style={{ fontSize: 12, color: 'var(--m-text-2)', marginBottom: 4,
          display: 'flex', alignItems: 'center', gap: 4 }}>
          📷 {label}
          <span style={{ color: 'var(--m-text-3)', fontSize: 10 }}>（已 {items.length}/{maxCount}）</span>
        </div>
      )}

      {/* 纯自绘 flex-wrap 容器 —— 缩略图 + "+" 直接并列在同一层级，
          只有当前行满了才自动换行，"+" 永远紧挨最后一张图片。*/}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
        {items.map((item, idx) => (
          <div key={idx}
            onClick={() => !(item as any).uploading && handleThumbClick(item)}
            style={{
              width: 80, height: 80,
              borderRadius: 8, overflow: 'hidden',
              border: '1px solid var(--m-border)',
              boxSizing: 'border-box',
              cursor: (item as any).uploading ? 'default' : 'pointer', background: 'var(--m-surface-2)',
              flexShrink: 0, position: 'relative',
            }}
          >
            {/* 右上角删除角标 —— 直接点就删，不再依赖 ActionSheet */}
            {!readOnly && !item.uploading && deleteUrl && (
              <div
                onClick={(e) => {
                  e.stopPropagation()  // 防止冒泡触发预览
                  handleDelete(getRawUrl(item), (item as any).imageId)
                }}
                style={{
                  position: 'absolute', top: -6, right: -6,
                  width: 20, height: 20, borderRadius: '50%',
                  background: 'rgba(0,0,0,0.65)', color: '#fff',
                  fontSize: 12, lineHeight: '20px', textAlign: 'center',
                  cursor: 'pointer', zIndex: 3,
                  boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
                  border: '1.5px solid #fff',
                }}
                aria-label="删除"
              >✕</div>
            )}
            {(item as any).uploading ? (
              <div style={{
                width: '100%', height: '100%',
                background: '#eee',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <div style={{
                  position: 'absolute', inset: 0,
                  background: 'rgba(0,0,0,0.55)', color: '#fff',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexDirection: 'column', fontSize: 10, gap: 4,
                }}>
                  <DotLoading color="white" size={24} />
                  <div>上传中...</div>
                </div>
              </div>
            ) : (
              <Image
                src={typeof item.url === 'string' ? item.url : getRawUrl(item)}
                fit="cover"
                width={80}
                height={80}
                alt=""
                style={{ display: 'block', width: '100%', height: '100%' }}
              />
            )}
          </div>
        ))}

        {!readOnly && remaining > 0 && (
          <div
            onClick={handleAddClick}
            style={{
              width: 80, height: 80,
              border: '1px dashed var(--adm-color-border, #cccccc)',
              borderRadius: 8,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--adm-color-weak, #999)',
              fontSize: 36, fontWeight: 300, lineHeight: 1,
              cursor: 'pointer', userSelect: 'none',
              boxSizing: 'border-box',
              flexShrink: 0,
            }}
          >+</div>
        )}
      </div>

      {/* 两个隐藏 <input type="file"> —— 被 ActionSheet 选择后触发 */}
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        style={{ display: 'none' }}
        onChange={(e) => { handleFiles(e.target.files); resetInput(e.target) }}
      />
      <input
        ref={galleryInputRef}
        type="file"
        accept="image/*"
        multiple
        style={{ display: 'none' }}
        onChange={(e) => { handleFiles(e.target.files); resetInput(e.target) }}
      />
    </div>
  )
}
