/**
 * 移动报工主页面 — 职责：阶段切换 + 数据加载 + 布局
 * 各 Tab 的业务逻辑（新增/编辑/删除/图片上传）已抽到 reporting/ 目录下 6 个独立 SubPanel
 *
 * 页面结构（按需求 v2）：
 *   ┌─ 工单信息 + 报工统计（顶部）
 *   ├─ 工序报工（分组容器，工序 Select + [不良][投料] 两 Tab）
 *   ├─ 工单报工（分组容器，[报废][工时][人员] 三 Tab）
 *   └─ 完工/返回 按钮
 */
import { useEffect, useMemo, useState, useCallback, type ReactNode } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { Dialog, Toast, Button, Tabs, Badge } from 'antd-mobile'
import api from '../../utils/api'
import { calcReportStats } from '../../pages/production/reportStats'
import { useKeyboardInset } from '../hooks/useKeyboardInset'
import { fmtInt } from '../utils/format'

// SubPanel
import { ProcessDefectPanel } from './reporting/ProcessDefectPanel'
import { ProcessMaterialPanel } from './reporting/ProcessMaterialPanel'
import { ScrapPanel } from './reporting/ScrapPanel'
import { ExceptionPanel } from './reporting/ExceptionPanel'
import { ManpowerPanel } from './reporting/ManpowerPanel'
import { BatchTagPanel } from './reporting/BatchTagPanel'

// 共享类型（集中导出）
import type {
  ProcessRow, ReportOrder, OrderRow, DefectType, MaterialMaster,
  DefectRow, MaterialRow, ScrapRow, ExceptionRow, ManpowerRow,
} from './reporting/types'

// ============ 主组件 ============
export default function MobileProcessReporting() {
  const navigate = useNavigate()
  const [sp] = useSearchParams()
  const urlOrderId = sp.get('orderId')

  // 阶段：select（选工单）→ reporting（报工）
  const [phase, setPhase] = useState<'select' | 'reporting'>('select')

  // ========== 阶段1：工单选择 ==========
  const [orders, setOrders] = useState<OrderRow[]>([])
  const [current, setCurrent] = useState<ReportOrder | null>(null)

  // ========== 阶段2：报工数据 ==========
  const [processes, setProcesses] = useState<ProcessRow[]>([])
  // 三个独立工序选择器（不良/物料/报废 Tab 各自维护，互不影响）
  const [defectProcId, setDefectProcId] = useState<number | null>(null)
  const [materialProcId, setMaterialProcId] = useState<number | null>(null)
  const [scrapProcId, setScrapProcId] = useState<number | null>(null)

  // 一级 Tab: process（工序报工）| report（工单报工）
  const [groupTab, setGroupTab] = useState<'process' | 'report'>('process')
  // 工序报工内部 Tab: defect | material | scrap（检验报废移到这里）
  const [processTab, setProcessTab] = useState<'defect' | 'material' | 'scrap'>('defect')
  // 工单报工内部 Tab: exception | manpower | batch-tag（报废已移到工序记录）
  const [reportTab, setReportTab] = useState<'exception' | 'manpower' | 'batch-tag'>('exception')

  // ========== 未保存 dirty 收集 ==========
  // 每个 Panel 通过 onDirtyChange(key, dirty) 上报，父组件汇总
  const [dirtyMap, setDirtyMap] = useState<Record<string, boolean>>({})
  const dirtyCount = useMemo(() => Object.values(dirtyMap).filter(Boolean).length, [dirtyMap])
  const setPanelDirty = useCallback((key: string, dirty: boolean) => {
    setDirtyMap(prev => {
      if (prev[key] === dirty) return prev
      return { ...prev, [key]: dirty }
    })
  }, [])

  /** 通用离开拦截：有 dirty 弹 Dialog 确认 */
  const guardLeave = useCallback(async (label: string): Promise<boolean> => {
    if (dirtyCount === 0) return true
    const ok = await Dialog.confirm({
      content: `当前有 ${dirtyCount} 处未保存的修改，确定${label}？`,
      confirmText: '确定',
      cancelText: '取消',
    })
    return !!ok
  }, [dirtyCount])

  const trySwitchGroupTab = useCallback(async (k: 'process' | 'report') => {
    if (k === groupTab) return
    if (await guardLeave('切换页签')) setGroupTab(k)
  }, [groupTab, guardLeave])

  const trySwitchProcessTab = useCallback(async (k: 'defect' | 'material' | 'scrap') => {
    if (k === processTab) return
    if (await guardLeave('切换页签')) setProcessTab(k)
  }, [processTab, guardLeave])

  const trySwitchReportTab = useCallback(async (k: 'exception' | 'manpower' | 'batch-tag') => {
    if (k === reportTab) return
    if (await guardLeave('切换页签')) setReportTab(k)
  }, [reportTab, guardLeave])

  const tryBack = useCallback(async () => {
    if (await guardLeave('返回工单列表')) {
      setCurrent(null); setPhase('select')
    }
  }, [guardLeave])

  // 全量记录（SubPanel 各自按 process_id 过滤）
  // 🔑 注意：defectsRaw 是 ProcessDefect 全量（不良+报废共用同一张表），前端按 scrapTypes 字典分类
  const [defectsRaw, setDefectsRaw] = useState<DefectRow[]>([])
  const [materials, setMaterials] = useState<MaterialRow[]>([])
  const [exceptions, setExceptions] = useState<ExceptionRow[]>([])
  const [manpower, setManpower] = useState<ManpowerRow | null>(null)

  // 字典预加载
  const [defectTypes, setDefectTypes] = useState<DefectType[]>([])
  const [scrapTypes, setScrapTypes] = useState<DefectType[]>([])

  // 🔑 从全量 ProcessDefect 里按字典派生工序不良 / 检验报废
  const scrapDefectIds = useMemo(() => new Set(scrapTypes.map(t => t.defect_id)), [scrapTypes])
  const defects = useMemo(() => defectsRaw.filter(d => !scrapDefectIds.has(Number(d.defect_type_id))), [defectsRaw, scrapDefectIds])
  const scraps = useMemo(() => defectsRaw.filter(d => scrapDefectIds.has(Number(d.defect_type_id))), [defectsRaw, scrapDefectIds])
  const [materialsMaster, setMaterialsMaster] = useState<MaterialMaster[]>([])

  // 软键盘遮挡高度（px）— visualViewport 差值算出，不拍脑袋固定像素
  // adjustResize 模式下 WebView 变矮，inset=0；adjustPan 下返回键盘实际高度
  const keyboardInset = useKeyboardInset()

  // ========== 键盘避让已抽 useKeyboardAvoidance hook（MobileLayout 全局挂载，见 src/mobile/hooks/useKeyboardAvoidance.ts） ==========
  // ========== 阶段1 加载：生产订单 ==========
  useEffect(() => {
    if (phase !== 'select') return
    ;(async () => {
      try {
        // 只查 status=2（开工）— 报工选择页只应显示已开工订单
        // MobileOrderManagement 的开工按钮会先 POST 创建报工单（syncOrderStatus 同步推订单到开工），
        // 然后才 navigate 带 orderId 过来，所以此时订单必然已是 status=2
        const res: any = await api.get('/production/orders', { params: { status: 2, pageSize: 100 } })
        const list = (res?.data?.items || res?.data?.list || res?.data || []) as OrderRow[]
        setOrders(list)

        // URL 带 orderId：在已开工列表里匹配（没匹配到说明该订单还没开工，前端不自动创建）
        if (urlOrderId) {
          const order = list.find(o => String(o.order_id) === String(urlOrderId))
          if (order) await handleStartNew(order)
        }
      } catch (e) { /* 静默 */ }
    })()
  }, [phase, urlOrderId])

  // ========== 字典预加载 ==========
  useEffect(() => {
    ;(async () => {
      try {
        const [dtr, mtr] = await Promise.all([
          api.get('/basic/defect-types', { params: { pageSize: 500 } }) as Promise<any>,
          api.get('/basic/materials', { params: { page: 1, pageSize: 1000 } }) as Promise<any>,
        ])
        const dt = (dtr?.data?.items || dtr?.data || []) as DefectType[]
        // 后端 Material 模型主键叫 material_id（UUID），但前端 MaterialMaster 接口约定叫 bas_material_id
        // → 拉取后统一做字段映射，下游 ProcessMaterialPanel 等组件都用 bas_material_id
        const mt: MaterialMaster[] = (mtr?.data?.rows || mtr?.data?.items || mtr?.data || []).map((m: any) => ({
          bas_material_id: m.bas_material_id || m.material_id,   // 兼容两种返回
          material_code: m.material_code,
          material_name: m.material_name,
          specification: m.specification,
          ...m,
        }))
        // 工序不良类型
        setDefectTypes(dt.filter(t => t.category_name === '制程检验类型' && t.defect_type !== '检验报废'))
        // 报废类型
        setScrapTypes(dt.filter(t => t.defect_type === '检验报废' || t.category_name === '报废类型'))
        setMaterialsMaster(mt)
      } catch { /* 静默 */ }
    })()
  }, [])

  // ========== 开工创建报工单 ==========
  const handleStartNew = async (order: OrderRow) => {
    try {
      // 检查是否已有报工单
      const exist: any = await api.get('/production/report-orders', { params: { order_id: order.order_id, status: '生产中', pageSize: 1 } })
      const activeReport = (exist?.data?.items || exist?.data || [])[0]
      if (activeReport) {
        await enterReporting(activeReport)
        return
      }
      Toast.show({ content: '正在创建报工单...', icon: 'loading' })
      const create: any = await api.post('/production/report-orders', {
        order_id: order.order_id, line_id: order.line_id, report_qty: order.finished_qty || order.planned_qty,
      })
      if (!create?.success) throw new Error(create?.message || '创建失败')
      Toast.show({ content: '报工单已创建', icon: 'success' })
      await enterReporting(create.data)
    } catch (e: any) {
      Toast.show({ content: e?.message || '开工失败', icon: 'fail' })
    }
  }

  // ========== 进入报工：拉全量数据 ==========
  const enterReporting = async (report: ReportOrder) => {
    setCurrent(report)
    setPhase('reporting')
    setGroupTab('process')
    setProcessTab('defect')
    setReportTab('exception')
    try {
      // 工序
      const procs: any = await api.get(`/production/report-orders/${report.report_order_id}/processes`)
      const plist = ((procs?.data || []) as ProcessRow[]).sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0))
      setProcesses(plist)
      if (plist.length > 0) {
        const first = plist[0].process_id
        setDefectProcId(first)
        setMaterialProcId(first)
        setScrapProcId(first)
      }

      // 全量记录（报废也走 process-defects，前端按 scrapTypes 字典分类）
      const [dr, mr, er, pr]: any[] = await Promise.all([
        api.get('/production/process-defects', { params: { report_order_id: report.report_order_id, pageSize: 500 } }),
        api.get('/production/process-materials', { params: { report_order_id: report.report_order_id, pageSize: 500 } }),
        api.get('/production/process-exceptions', { params: { report_order_id: report.report_order_id, pageSize: 200 } }),
        api.get('/production/manpower-records', { params: { report_order_id: report.report_order_id, pageSize: 1 } }),
      ])
      const _arr = (r: any) => (r?.data?.items || r?.data || []) as any[]
      // 🔑 后端 include DefectType 后，defect_type 是对象不是字符串，前端渲染会崩溃（React #31）
      // 这里统一归一化：defect_type 取字符串，同时取出关联的 defect_code/defect_name
      setDefectsRaw(_arr(dr).map((d: any) => {
        const dt = d.defect_type
        if (dt && typeof dt === 'object') {
          return {
            ...d,
            defect_type_id: d.defect_type_id ?? dt.defect_id,
            defect_code: d.defect_code ?? dt.defect_code,
            defect_name: d.defect_name ?? dt.defect_name,
            defect_type: dt.defect_type ?? dt.category_name ?? '',   // ← 关键：对象→字符串
            defect_unit: d.defect_unit ?? dt.defect_unit,
          }
        }
        return d
      }) as DefectRow[])
      setMaterials(_arr(mr) as MaterialRow[])
      setExceptions(_arr(er) as ExceptionRow[])
      setManpower((_arr(pr)[0] || null) as ManpowerRow | null)
    } catch { /* 静默 */ }
  }

  // ========== 完工：预检 → 弹窗 → 确认 ==========
  const finishReport = useCallback(async () => {
    if (!current) return
    let pre: any
    try {
      pre = await api.get(`/production/report-orders/${current.report_order_id}/pre-check`)
    } catch (e: any) {
      Dialog.show({ content: '预检失败：' + (e?.message || e), closeOnAction: true })
      return
    }
    const data = pre?.data || pre
    const items: Array<{ level: 'pass' | 'warn' | 'block'; label: string; detail?: string }> = data.items || []
    const passCount = items.filter(i => i.level === 'pass').length
    const warnCount = items.filter(i => i.level === 'warn').length
    const blockCount = items.filter(i => i.level === 'block').length
    const hasBlock = blockCount > 0
    const iconMap: Record<string, string> = { pass: '✅', warn: '⚠️', block: '❌' }
    const colorMap: Record<string, string> = { pass: '#52c41a', warn: '#faad14', block: '#ff4d4f' }

    Dialog.show({
      content: (
        <div style={{ padding: '8px 4px', maxHeight: '60vh', overflowY: 'auto', minWidth: 260 }}>
          <div style={{ fontWeight: 600, marginBottom: 8, fontSize: 14 }}>完工前检查</div>
          {items.map((it, i) => (
            <div key={i} style={{ marginBottom: 6 }}>
              <div style={{ fontSize: 13, color: colorMap[it.level] }}>
                {iconMap[it.level]} {it.label}
              </div>
              {it.detail && (
                <div style={{ fontSize: 11, color: 'var(--m-text-3)', marginTop: 2, lineHeight: 1.4 }}>{it.detail}</div>
              )}
            </div>
          ))}
          <div style={{
            marginTop: 10, padding: '6px 8px',
            background: hasBlock ? 'var(--m-status-urgent-bg)' : 'var(--m-status-done-bg)',
            borderRadius: 6, fontSize: 12,
            color: hasBlock ? 'var(--m-status-urgent)' : 'var(--m-status-done)',
          }}>
            {hasBlock
              ? `❌ ${passCount} 通过 · ${warnCount} 警告 · ${blockCount} 阻断，不能完工`
              : `✅ ${passCount} 通过 · ${warnCount} 警告，可以完工`}
          </div>
        </div>
      ),
      actions: [
        { key: 'back', text: '补录继续', style: { color: 'var(--m-text-3)' } },
        { key: 'ok', text: '确认完工', disabled: hasBlock, danger: true },
      ],
      closeOnAction: true,
      onAction: async (action) => {
        if (action.key !== 'ok') return  // 补录继续：closeOnAction=true 已自动关闭
        try {
          Toast.show({ content: '正在完工...', icon: 'loading' })
          const r: any = await api.post(`/production/report-orders/${current.report_order_id}/finish`)
          if (!r?.success) throw new Error(r?.message || '完工失败')
          Toast.show({ content: '✅ 已完工', icon: 'success' })
          setCurrent(null); setPhase('select')
          setDefectsRaw([]); setMaterials([]); setExceptions([]); setManpower(null)
        } catch (e: any) {
          Toast.show({ content: e?.message || '完工失败', icon: 'fail' })
        }
      },
    })
  }, [current])

  // ========== 报工统计（复用 PC 端纯函数） ==========
  const stats = useMemo(() => calcReportStats({
    defects, scraps, exceptions, materials,
    manpowers: manpower ? [manpower] : [],
    lineProcesses: processes,
    selectedReport: current ? { ...current, status: current.status != null ? String(current.status) : null } : null,
  }), [defects, scraps, exceptions, materials, manpower, processes, current])

  const editable = useMemo(() => current && String(current.status) !== '已完工' && String(current.status) !== '4', [current])

  // ========== 渲染 ==========
  if (phase === 'select') {
    return (
      <div className="mobile-page-fixed-header">
        <div className="mobile-sticky-header">
          <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--m-text)', paddingTop: 4 }}>
            📋 选择开工订单
          </div>
          <div style={{ fontSize: 12, color: 'var(--m-text-3)', marginTop: 2 }}>
            选一个已开工的报工单开始报工
          </div>
        </div>
        <div className="mobile-page-scroll-list mobile-scroll">
          {orders.length === 0 && (
            <div style={{ color: 'var(--m-text-3)', textAlign: 'center', padding: 40 }}>
              — 暂无开工订单 —
            </div>
          )}
          {orders.map((o) => (
            <div key={o.order_id} style={{
              background: 'var(--m-surface)', borderRadius: 10, padding: 12, margin: '0 2px 10px',
              border: '1px solid var(--m-border)',
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 600 }}>{o.order_no}</div>
                  <div style={{ fontSize: 12, color: 'var(--m-text-3)', marginTop: 3 }}>{o.material_code} · {o.material_name}</div>
                </div>
                <Badge content={`${fmtInt(o.finished_qty)}/${fmtInt(o.planned_qty)}`} style={{ '--right': '-4px', '--top': '-4px' }} />
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                <Button size="mini" color="primary" onClick={() => handleStartNew(o)}>▶ 开工报工</Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  if (!current) return null

  return (
    <div className="mobile-page-fixed-header">
      {/* ========== 滚动区（唯一滚动源） ==========
       * Header/StatsBar 下沉到滚动区顶部，随列表滚走；
       * 一级 Tab 在滚动区内 sticky 吸顶，吸顶高度仅 ≈40px，
       * 横屏剩余可见高度从 61px 提升到 ~240px；
       * 滚动区 scroll-padding-top:44px 配合 scrollIntoView 让输入框
       * 精准停在 sticky 一级 Tab 正下方（输入法遮挡也一并解决）。 */}
      <div className="mobile-page-scroll-list mobile-scroll" style={{ padding: '0 10px 20px', paddingBottom: `calc(env(safe-area-inset-bottom) + 16px + ${keyboardInset}px)` }}>
        {/* Header + StatsBar —— 滚动区顶部，随列表滚走 */}
        <div style={{ marginTop: 10 }}>
          <Header report={current} onBack={tryBack} onFinish={finishReport} />
          <StatsBar stats={stats} reportQty={current.report_qty || 0} />
        </div>

        {/* 一级 Tab —— 滚动区内 sticky，40px 高 */}
        <div className="mobile-sticky-sub-header" style={{ paddingTop: 8 }}>
          <div style={{
            background: 'var(--m-surface)', borderRadius: 10,
            boxShadow: '0 1px 4px rgba(0,0,0,.04)', overflow: 'hidden',
          }}>
            <Tabs
              activeKey={groupTab}
              onChange={(k) => trySwitchGroupTab(k as any)}
              style={{ background: 'var(--m-surface-2)' }}
            >
              <Tabs.Tab title="🔧 工序报工" key="process" />
              <Tabs.Tab title="📊 工单报工" key="report" />
            </Tabs>
          </div>
        </div>

        {/* ========== 二级 Tab + Panel 内容 ========== */}
        <div style={{ paddingTop: 8 }}>
        {/* === 工序报工 Tab === */}
        {groupTab === 'process' && (
          <div>
            <PanelSubTabs active={processTab} onChange={(k) => trySwitchProcessTab(k as any)}>
              <Tabs.Tab title="工序不良" key="defect" />
              <Tabs.Tab title="物料使用" key="material" />
              <Tabs.Tab title="检验报废" key="scrap" />
            </PanelSubTabs>
            {processTab === 'defect' && (
              <ReportPanel>
                <ProcessSelector
                  processes={processes}
                  activeProcId={defectProcId}
                  onChange={setDefectProcId}
                />
                <ProcessDefectPanel
                  report={current}
                  activeProcessId={defectProcId}
                  editable={!!editable}
                  defectTypes={defectTypes}
                  allDefects={defects}
                  setAllDefects={(updater) => setDefectsRaw(prev => {
                    const scrap = prev.filter(d => scrapDefectIds.has(Number(d.defect_type_id)))
                    const nonScrap = prev.filter(d => !scrapDefectIds.has(Number(d.defect_type_id)))
                    return [...updater(nonScrap), ...scrap]
                  })}
                  onDirtyChange={(d) => setPanelDirty('defect', d)}
                />
              </ReportPanel>
            )}
            {processTab === 'material' && (
              <ReportPanel>
                <ProcessSelector
                  processes={processes}
                  activeProcId={materialProcId}
                  onChange={setMaterialProcId}
                />
                <ProcessMaterialPanel
                  report={current}
                  activeProcessId={materialProcId}
                  editable={!!editable}
                  materials={materialsMaster}
                  allMaterials={materials}
                  setAllMaterials={setMaterials}
                  onDirtyChange={(d) => setPanelDirty('material', d)}
                />
              </ReportPanel>
            )}
            {processTab === 'scrap' && (
              <ReportPanel>
                <ProcessSelector
                  processes={processes}
                  activeProcId={scrapProcId}
                  onChange={setScrapProcId}
                />
                <ScrapPanel
                  report={current}
                  activeProcessId={scrapProcId}
                  processes={processes}
                  editable={!!editable}
                  scrapTypes={scrapTypes}
                  rows={scraps}
                  setRows={(updater) => setDefectsRaw((prev) => {
                    const before = prev.filter(d => !scrapDefectIds.has(Number(d.defect_type_id)))
                    const scrapRows = prev.filter(d => scrapDefectIds.has(Number(d.defect_type_id))) as unknown as ScrapRow[]
                    const merged = updater(scrapRows)
                    const mergedDefects: DefectRow[] = merged.map((s) => ({
                      id: s.scrap_id ?? s.id,
                      defect_id: s.scrap_id ?? (s.id as number | undefined),
                      report_order_id: s.report_order_id,
                      process_id: processes.find(p => p.process_id === scrapProcId)?.process_id,
                      defect_type_id: s.defect_type_id,
                      defect_code: s.defect_code,
                      defect_name: s.defect_name,
                      defect_type: s.defect_type,
                      quantity: s.quantity,
                    }))
                    return [...before, ...mergedDefects]
                  })}
                  onDirtyChange={(d) => setPanelDirty('scrap', d)}
                />
              </ReportPanel>
            )}
          </div>
        )}

        {/* === 工单记录 Tab（工时 + 人员） === */}
        {groupTab === 'report' && (
          <div>
            <PanelSubTabs active={reportTab} onChange={(k) => trySwitchReportTab(k as any)}>
              <Tabs.Tab title="停机停线" key="exception" />
              <Tabs.Tab title="人员工时" key="manpower" />
              <Tabs.Tab title="批次标签" key="batch-tag" />
            </PanelSubTabs>
            {reportTab === 'exception' && (
              <ReportPanel>
                <ExceptionPanel
                  report={current}
                  editable={!!editable}
                  rows={exceptions}
                  setRows={setExceptions}
                  onDirtyChange={(d) => setPanelDirty('exception', d)}
                />
              </ReportPanel>
            )}
            {reportTab === 'manpower' && (
              <ReportPanel>
                <ManpowerPanel
                  report={current}
                  editable={!!editable}
                  manpower={manpower}
                  setManpower={setManpower}
                  onDirtyChange={(d) => setPanelDirty('manpower', d)}
                />
              </ReportPanel>
            )}
            {reportTab === 'batch-tag' && current && (
              <ReportPanel>
                <BatchTagPanel
                  report={current}
                  editable={!!editable}
                  onSaved={(patch) => setCurrent((prev) => prev ? { ...prev, ...patch } : prev)}
                />
              </ReportPanel>
            )}
          </div>
        )}
        </div>
      </div>
    </div>
  )
}

// ========== 小组件 ==========

function Header({ report, onBack, onFinish }: { report: ReportOrder; onBack: () => void; onFinish: () => void }) {
  const statusText = { '开工': '生产中', '完工': '已完工', '关闭': '已关闭', '下发': '已下发', '开立': '待开工' }[String(report.status)] || String(report.status)
  const isDone = String(report.status) === '4' || String(report.status) === '已完工'
  return (
    <div style={{
      background: 'linear-gradient(135deg,#1890ff,#096dd9)', color: 'var(--m-surface)',
      padding: '12px 14px',
    }}>
      {/* 行1：编号 + 状态 + 完工按钮 同一行（返回按钮已移除，由系统返回手势替代） */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontSize: 16, fontWeight: 700 }}>📝 {report.report_no}</span>
        <span style={{
          fontSize: 11, padding: '2px 8px', borderRadius: 10, flexShrink: 0,
          background: isDone ? 'var(--m-status-done)' : statusText === '生产中' ? 'var(--m-status-pending)' : 'rgba(255,255,255,.25)',
        }}>{statusText}</span>
        <div style={{ flex: 1 }} />
        {!isDone && (
          <Button size="mini" color="danger" onClick={onFinish} style={{ background: '#ff4d4f' }}>完工</Button>
        )}
      </div>
      {/* 行2：订单 + 产线 */}
      <div style={{ fontSize: 11, opacity: .85, marginTop: 4 }}>
        订单 {report.order_no} · {report.line_name}
      </div>
      {/* 行3：料号 + 报工数量 */}
      <div style={{ fontSize: 11, opacity: .85, marginTop: 1 }}>
        {report.material_code} {report.material_name} · 报工 {fmtInt(report.report_qty)}
      </div>
    </div>
  )
}

function StatsBar({ stats, reportQty }: { stats: ReturnType<typeof calcReportStats>; reportQty: number }) {
  // 合格数量/投入数量 上移到标题行右侧（右对齐），下方只保留 4 项不良/工时
  const inputInt = fmtInt(stats.inputQty)
  const qualifiedInt = fmtInt(stats.expectedOutput > 0 ? stats.expectedOutput : 0)
  const items: Array<{ label: string; value: React.ReactNode; color?: string }> = [
    { label: '来料不良', value: fmtInt(stats.defectMaterial), color: '#faad14' },
    { label: '制程不良', value: fmtInt(stats.defectProcess), color: '#fa8c16' },
    { label: '检验报废', value: fmtInt(stats.defectScrap), color: 'var(--brand-color-danger)' },
    { label: '异常工时 / 总工时(H)', value: `${(stats.exceptionHours || 0).toFixed(1)} / ${(stats.manpowerHours || 0).toFixed(1)}H`, color: '#eb2f96' },
  ]
  return (
    <div style={{
      background: 'var(--m-surface)', margin: '10px 0 0', borderRadius: 10, padding: '10px 12px',
      boxShadow: '0 1px 4px rgba(0,0,0,.04)',
    }}>
      {/* 标题行：左标题 + 右合格/投入比值（右对齐） */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
        <div style={{ fontSize: 11, color: 'var(--m-text-3)', fontWeight: 600 }}>📊 报工单汇总</div>
        <div style={{ fontSize: 16, fontWeight: 700 }}>
          <span style={{ color: '#52c41a' }}>{qualifiedInt}</span>
          <span style={{ color: 'var(--m-text-3)', margin: '0 2px' }}>/</span>
          <span style={{ color: 'var(--brand-color)' }}>{inputInt}</span>
        </div>
      </div>
      {/* 数据行：4 项 flex 平分 */}
      <div style={{ display: 'flex', gap: 4, alignItems: 'stretch' }}>
        {items.map(it => (
          <div key={it.label} style={{ flex: 1, textAlign: 'center', minWidth: 0 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: it.color, whiteSpace: 'nowrap' }}>{it.value}</div>
            <div style={{ fontSize: 10, color: 'var(--m-text-3)', marginTop: 2, whiteSpace: 'nowrap' }}>{it.label}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

/** 报工 Panel 统一卡片容器 —— 工序选择器 + 操作面板包一层圆角卡 */
function ReportPanel({ children }: { children: ReactNode }) {
  return (
    <div style={{
      background: 'var(--m-surface)', borderRadius: 10,
      boxShadow: '0 1px 4px rgba(0,0,0,.04)', overflow: 'hidden',
      marginTop: 8,
    }}>
      {children}
    </div>
  )
}

/** 工序/工单 二级 Tab 容器 —— 统一卡片样式 + flex-shrink 防止被压扁 */
function PanelSubTabs({
  active, onChange, children,
}: {
  active: string
  onChange: (k: string) => void
  children: ReactNode
}) {
  return (
    <div style={{
      background: 'var(--m-surface)', borderRadius: 10,
      boxShadow: '0 1px 4px rgba(0,0,0,.04)', overflow: 'hidden',
    }}>
      <Tabs activeKey={active} onChange={(k) => onChange(k as string)}>{children}</Tabs>
    </div>
  )
}

/**
 * 工序选择器 — 必报工序 option 带前缀 "*"，选中后右侧显示红色 [必报] 徽章
 */
function ProcessSelector({
  processes, activeProcId, onChange,
}: {
  processes: ProcessRow[]
  activeProcId: number | null
  onChange: (id: number | null) => void
}) {
  const current = processes.find(p => p.process_id === activeProcId)
  return (
    <div style={{
      padding: '8px 12px', borderBottom: '1px solid var(--m-border)', background: 'var(--m-surface-2)',
      display: 'flex', alignItems: 'center', gap: 8,
    }}>
      <span style={{ fontSize: 12, color: 'var(--m-text-3)', flexShrink: 0 }}>工序</span>
      <select
        value={activeProcId || ''}
        onChange={(e) => onChange(e.target.value ? Number(e.target.value) : null)}
        style={{
          flex: 1, padding: '7px 10px', borderRadius: 6,
          border: '1px solid var(--m-border)', fontSize: 13, background: 'var(--m-surface)',
        }}
      >
        {processes.map(p => (
          <option key={p.process_id} value={p.process_id}>
            {p.must_report ? '* ' : ''}{p.sort_order}. {p.process_name}
          </option>
        ))}
      </select>
      {current?.must_report && (
        <span style={{
          fontSize: 10, padding: '1px 6px', borderRadius: 10,
          background: '#f44336', color: 'var(--m-surface)', fontWeight: 700, flexShrink: 0,
        }}>必报</span>
      )}
    </div>
  )
}
