/**
 * 校准提醒（Phase 2 · Q-B）
 *
 * Tab 1: 即将到期（默认 30 天内）
 * Tab 2: 已逾期
 *
 * 后端接口：
 *   GET /api/basic/device-calibration-plans/expiring/list?days=30
 *   GET /api/basic/device-calibration-plans/overdue/list
 */
import { useEffect, useState } from 'react'
import { Tabs, List, PullToRefresh, Toast, Empty, Button } from 'antd-mobile'
import api from '../../utils/api'
import { useApp } from '../../contexts/AppContext'
import { useBarcode } from '../hooks/useBarcode'

interface PlanRow {
  plan_id: number
  asset_id?: number
  asset_code?: string
  asset_name?: string
  calibration_cycle?: number
  last_calibration_date?: string
  next_calibration_date?: string
  calibration_org?: string
  status?: string | number
  remarks?: string
}

type Tab = 'expiring' | 'overdue'

function daysBetween(iso?: string): number | null {
  if (!iso) return null
  const a = new Date(iso).getTime()
  if (isNaN(a)) return null
  const b = new Date()
  b.setHours(0, 0, 0, 0)
  return Math.round((a - b.getTime()) / (1000 * 60 * 60 * 24))
}

function statusTag(s?: string | number) {
  if (!s) return null
  const text = String(s)
  const isOk = text.includes('已校准')
  const isLocked = text.includes('锁定')
  // 【UI 重构 2026-11-07】统一使用 mobile.css --m-status-* 变量
  const bg = isOk ? 'var(--m-status-done-bg)' : isLocked ? 'var(--m-status-skipped-bg)' : 'var(--m-status-pending-bg)'
  const color = isOk ? 'var(--m-status-done)' : isLocked ? 'var(--m-text-3)' : 'var(--m-status-pending)'
  return (
    <span style={{
      fontSize: 11, padding: '1px 8px', borderRadius: 8, background: bg, color,
    }}>{text}</span>
  )
}

export default function MobileCalibrationReminder() {
  const { hasPermission } = useApp()
  const { scan } = useBarcode()
  const [tab, setTab] = useState<Tab>('expiring')
  const [list, setList] = useState<PlanRow[]>([])
  const [loading, setLoading] = useState(false)
  const [daysFilter, setDaysFilter] = useState(15)
  const [expiringCount, setExpiringCount] = useState(0)
  const [overdueCount, setOverdueCount] = useState(0)
  const [scannedHighlight, setScannedHighlight] = useState<string | null>(null)

  // 【UI 重构】扫码查校准：前端在 list 里按 asset_code 匹配
  const handleScanForCalibration = async () => {
    const r = await scan(); if (!r) return
    setScannedHighlight(r.code)
    const match = list.find((p) => p.asset_code === r.code)
    if (match) {
      Toast.show({
        content: `已定位：${match.asset_name || match.asset_code}（${match.status === '已逾期' ? '已逾期' : '即将到期'}）`,
        position: 'bottom',
        duration: 2000,
      })
    } else {
      Toast.show({
        content: `设备 ${r.code} 不在当前列表，切换 Tab 试试`,
        position: 'bottom',
        duration: 1800,
      })
    }
  }

  const fetchList = async () => {
    setLoading(true)
    try {
      let endpoint = ''
      const params: Record<string, unknown> = {}
      if (tab === 'expiring') {
        endpoint = '/basic/device-calibration-plans/expiring/list'
        params.days = daysFilter
      } else {
        endpoint = '/basic/device-calibration-plans/overdue/list'
      }
      const r: any = await api.get(endpoint, { params })
      if (r.success) {
        setList(Array.isArray(r.data) ? r.data : (r.data?.rows || r.data?.list || []))
      } else {
        setList([])
      }
    } catch {
      setList([])
    } finally {
      setLoading(false)
    }
  }

  // 首次进入同时查两个计数
  const fetchCounts = async () => {
    try {
      const [e, o] = await Promise.all([
        api.get('/basic/device-calibration-plans/expiring/list', { params: { days: 30 } }).catch(() => null),
        api.get('/basic/device-calibration-plans/overdue/list').catch(() => null),
      ])
      setExpiringCount(Array.isArray(e?.data) ? e.data.length : (e?.data?.rows?.length || e?.data?.total || 0))
      setOverdueCount(Array.isArray(o?.data) ? o.data.length : (o?.data?.rows?.length || o?.data?.total || 0))
    } catch {}
  }

  useEffect(() => { fetchList() }, [tab, daysFilter])
  useEffect(() => { fetchCounts() }, [])

  const onRefresh = async () => { await fetchList(); await fetchCounts(); Toast.show({ content: '已刷新', icon: 'success', position: 'bottom', duration: 600 }) }

  return (
    <div className="mobile-page mobile-page-scrollable" style={{ paddingTop: 12 }}>
      {/* 【UI 重构】扫码查校准入口 */}
      {hasPermission('device:calibration:view') && (
        <Button
          block
          size="large"
          fill="outline"
          onClick={handleScanForCalibration}
          style={{
            marginBottom: 10,
            height: 40,
            fontSize: 14,
            borderColor: 'var(--brand-color)',
            color: 'var(--brand-color)',
          }}
        >
          📷 扫码查设备校准
        </Button>
      )}

      <Tabs activeKey={tab} onChange={(k) => setTab(k as Tab)} style={{ marginBottom: 8 }}>
        <Tabs.Tab title={`⏰ 即将到期(${expiringCount})`} key="expiring" />
        <Tabs.Tab title={`🚨 已逾期(${overdueCount})`} key="overdue" />
      </Tabs>

      {/* 即将到期 → 可调节天数范围 */}
      {tab === 'expiring' && (
        <div style={{ display: 'flex', gap: 6, padding: '4px 0 10px', overflowX: 'auto' }}>
          {[7, 15, 30, 60].map((d) => (
            <span
              key={d}
              onClick={() => setDaysFilter(d)}
              style={{
                padding: '5px 12px', borderRadius: 14, fontSize: 12,
                background: daysFilter === d ? 'var(--brand-color-warning)' : 'var(--m-surface-2)',
                color: daysFilter === d ? 'var(--m-surface)' : 'var(--m-text-2)',
                cursor: 'pointer', whiteSpace: 'nowrap',
              }}
            >{d}天内</span>
          ))}
        </div>
      )}

      {loading ? (
        <div style={{ textAlign: 'center', padding: 40, color: 'var(--m-text-3)' }}>加载中...</div>
      ) : list.length === 0 ? (
        <Empty description={tab === 'expiring' ? `${daysFilter}天内无到期校准计划` : '暂无逾期校准计划'} />
      ) : (
        <PullToRefresh onRefresh={onRefresh}>
          <List>
            {list.map((p) => {
              const days = daysBetween(p.next_calibration_date)
              const urgent = tab === 'overdue' || (days !== null && days <= 3)
              return (
                <List.Item
                  key={p.plan_id}
                  description={
                    <div style={{ fontSize: 12, color: 'var(--m-text-3)', marginTop: 4 }}>
                      上次：{p.last_calibration_date || '—'} · 周期：{p.calibration_cycle || '—'}月
                      {p.calibration_org && ` · ${p.calibration_org}`}
                    </div>
                  }
                >
                  <div>
                    <div style={{ fontWeight: 500, fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span style={urgent ? { color: 'var(--brand-color-danger)' } : undefined}>
                        {p.asset_code} · {p.asset_name}
                      </span>
                      {statusTag(p.status)}
                    </div>
                    <div style={{ fontSize: 12, color: urgent ? 'var(--brand-color-danger)' : 'var(--m-text-2)', marginTop: 3, fontWeight: 500 }}>
                      到期：{p.next_calibration_date || '—'}
                      {days !== null && tab === 'expiring' && (
                        <span style={{ marginLeft: 6 }}>（还有 {days} 天）</span>
                      )}
                      {days !== null && tab === 'overdue' && (
                        <span style={{ marginLeft: 6, color: 'var(--brand-color-danger)' }}>（逾期 {Math.abs(days)} 天）</span>
                      )}
                    </div>
                  </div>
                </List.Item>
              )
            })}
          </List>
        </PullToRefresh>
      )}
    </div>
  )
}
